import fs from 'fs';
import path from 'path';

function buildPortableSingleFile() {
  console.log('Generating universal single-file portable HTML for mobile...');

  const distDir = path.resolve('dist');
  const avatarPath = path.join(distDir, 'daughter_avatar.jpg');
  const avatarBase64 = fs.readFileSync(avatarPath).toString('base64');
  const avatarDataUri = `data:image/jpeg;base64,${avatarBase64}`;

  // Read CSS files
  const assetsDir = path.join(distDir, 'assets');
  const cssFiles = fs.readdirSync(assetsDir).filter((f) => f.endsWith('.css'));
  let cssContent = '';
  for (const f of cssFiles) {
    cssContent += fs.readFileSync(path.join(assetsDir, f), 'utf8') + '\n';
  }

  // Read JS files
  const jsFiles = fs
    .readdirSync(assetsDir)
    .filter((f) => f.endsWith('.js') && !f.includes('aistudio'));
  let jsContent = '';
  for (const f of jsFiles) {
    jsContent += fs.readFileSync(path.join(assetsDir, f), 'utf8') + '\n';
  }

  // Replace avatar image paths with inline base64
  jsContent = jsContent.split('/daughter_avatar.jpg').join(avatarDataUri);
  jsContent = jsContent.split('"daughter_avatar.jpg"').join(`"${avatarDataUri}"`);

  // Protect against closing script tag inside jsContent
  jsContent = jsContent.replace(/<\/script>/gi, '<\\/script>');

  // Wrap in immediate IIFE and standard classic <script> tag:
  // This completely bypasses Chrome Android's local CORS restrictions on <script type="module">
  // when opening downloaded files directly from file:/// or content://!
  const singleHtml = `<!doctype html>
<html lang="fa" dir="rtl" style="background-color: #200c02; color-scheme: dark;">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
  <meta name="theme-color" content="#200c02" />
  <meta name="color-scheme" content="dark" />
  <meta name="mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
  <meta name="apple-mobile-web-app-title" content="جدول ضرب" />
  <title>بازی آموزش جدول ضرب فارسی</title>
  <style>
    :root, html, body {
      background-color: #200c02 !important;
      background: #200c02 !important;
      color-scheme: dark !important;
      -webkit-tap-highlight-color: transparent !important;
    }
    * {
      -webkit-tap-highlight-color: transparent !important;
    }
    @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap');
    ${cssContent}
  </style>
</head>
<body class="bg-[#200c02] text-amber-100 antialiased font-sans min-h-screen">
  <div id="root"></div>
  <script>
    window.__IS_PORTABLE__ = true;
    (function(){
      try {
        ${jsContent}
      } catch (err) {
        console.error("Game error:", err);
      }
    })();
  </script>
</body>
</html>`;

  // Write to public and dist
  if (!fs.existsSync('public')) fs.mkdirSync('public');
  fs.writeFileSync('public/jadval-zarb-portable.html', singleHtml, 'utf8');
  fs.writeFileSync(path.join(distDir, 'jadval-zarb-portable.html'), singleHtml, 'utf8');

  console.log('Universal portable file created successfully!');
  console.log(`File size: ${(singleHtml.length / (1024 * 1024)).toFixed(2)} MB`);
}

buildPortableSingleFile();
