import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { QuizCard } from './components/QuizCard';
import { CelebrationModal } from './components/CelebrationModal';
import { FailureModal } from './components/FailureModal';
import { WoodenLevelSelector } from './components/WoodenLevelSelector';
import { PreviewDownloadBanner } from './components/PreviewDownloadBanner';
import {
  generateQuestionsForLevel,
  loadGameProgress,
  saveGameProgress,
  Question,
  SavedProgress,
  getStoryRealm,
} from './utils/gameLogic';
import { soundManager } from './utils/soundEffects';

export default function App() {
  const [progress, setProgress] = useState<SavedProgress>(() => loadGameProgress());
  const [currentLevel, setCurrentLevel] = useState<number>(1);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [hasMadeMistake, setHasMadeMistake] = useState<boolean>(false);

  // Modals & Views - Initially open with the Wooden Level Selector
  const [showLevelSelect, setShowLevelSelect] = useState<boolean>(true);
  const [showCelebration, setShowCelebration] = useState<boolean>(false);
  const [showFailure, setShowFailure] = useState<boolean>(false);
  const [soundMuted, setSoundMuted] = useState<boolean>(() => soundManager.getMuted());

  // Initialize or change level
  const startLevel = useCallback((lvl: number) => {
    setCurrentLevel(lvl);
    const generated = generateQuestionsForLevel(lvl);
    setQuestions(generated);
    setCurrentIndex(0);
    setHasMadeMistake(false);
    setShowCelebration(false);
    setShowFailure(false);
    setShowLevelSelect(false);
  }, []);

  useEffect(() => {
    // Generate questions for the highest unlocked level
    const targetLvl = Math.min(progress.unlockedLevels, 11);
    setCurrentLevel(targetLvl);
    const generated = generateQuestionsForLevel(targetLvl);
    setQuestions(generated);
  }, [progress.unlockedLevels]);

  // Handle user's answer
  const handleAnswer = (chosenOption: number) => {
    if (!questions[currentIndex]) return;

    const currentQ = questions[currentIndex];
    const isCorrect = chosenOption === currentQ.answer;

    // Update the question state
    const updatedQuestions = [...questions];
    updatedQuestions[currentIndex] = {
      ...currentQ,
      userAnswer: chosenOption,
      isCorrect,
    };
    setQuestions(updatedQuestions);

    let currentRoundHadMistake = hasMadeMistake;
    if (!isCorrect) {
      currentRoundHadMistake = true;
      setHasMadeMistake(true);
    }

    // Check if round is finished
    if (currentIndex + 1 >= questions.length) {
      if (!currentRoundHadMistake) {
        // 100% PERFECT! Pass stage, unlock next realm, award fireworks!
        const nextLevel = currentLevel < 11 ? currentLevel + 1 : 11;
        const newUnlocked = Math.max(progress.unlockedLevels, nextLevel);
        const newCompleted = Array.from(new Set([...progress.completedLevels, currentLevel]));
        const newStars = progress.totalStars + 3;

        const newProg: SavedProgress = {
          unlockedLevels: newUnlocked,
          completedLevels: newCompleted,
          totalStars: newStars,
        };

        setProgress(newProg);
        saveGameProgress(newProg);
        setShowCelebration(true);
      } else {
        // Made at least 1 mistake -> cannot pass!
        setShowFailure(true);
      }
    } else {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  const handleNextLevel = () => {
    const nextLvl = currentLevel < 11 ? currentLevel + 1 : 11;
    startLevel(nextLvl);
  };

  const handleReplayLevel = () => {
    startLevel(currentLevel);
  };

  const handleToggleSound = () => {
    const muted = soundManager.toggleMute();
    setSoundMuted(muted);
  };

  const handleResetProgress = () => {
    const fresh: SavedProgress = {
      unlockedLevels: 1,
      completedLevels: [],
      totalStars: 0,
    };
    setProgress(fresh);
    saveGameProgress(fresh);
    setCurrentLevel(1);
    const generated = generateQuestionsForLevel(1);
    setQuestions(generated);
    setCurrentIndex(0);
    setHasMadeMistake(false);
    setShowCelebration(false);
    setShowFailure(false);
    setShowLevelSelect(true);
  };

  const currentQ = questions[currentIndex];
  const realm = getStoryRealm(currentLevel);

  // Count correct & wrong answers in current round
  const answeredQuestions = questions.filter((q) => q.userAnswer !== undefined);
  const wrongCount = answeredQuestions.filter((q) => q.userAnswer !== q.answer).length;
  const correctCount = answeredQuestions.filter((q) => q.userAnswer === q.answer).length;

  return (
    <div className="min-h-screen bg-wood-pattern text-amber-100 flex flex-col selection:bg-amber-700 selection:text-white">
      {/* Preview-only download banner (Hidden inside portable file) */}
      <PreviewDownloadBanner />

      {/* Top Header with Producer Credit and controls */}
      <Header
        currentLevel={currentLevel}
        totalStars={progress.totalStars}
        isMapActive={showLevelSelect}
        onOpenLevelMap={() => setShowLevelSelect(true)}
        onCloseLevelMap={() => setShowLevelSelect(false)}
        onResetProgress={handleResetProgress}
        soundMuted={soundMuted}
        onToggleSound={handleToggleSound}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full mx-auto px-2 sm:px-4 py-3 sm:py-6 flex flex-col justify-center items-center">
        {showLevelSelect ? (
          <div className="w-full flex flex-col items-center">
            {/* Wooden Level Selector matching the mobile game board */}
            <WoodenLevelSelector
              unlockedLevels={progress.unlockedLevels}
              completedLevels={progress.completedLevels}
              currentLevel={currentLevel}
              totalStars={progress.totalStars}
              onSelectLevel={(lvl) => startLevel(lvl)}
            />
          </div>
        ) : currentQ ? (
          /* Active Quiz View */
          <div className="w-full flex flex-col items-center space-y-4">
            <QuizCard
              question={currentQ}
              questionIndex={currentIndex}
              totalQuestions={questions.length}
              currentLevel={currentLevel}
              wrongCount={wrongCount}
              correctCount={correctCount}
              onAnswer={handleAnswer}
              onOpenMap={() => setShowLevelSelect(true)}
            />
          </div>
        ) : (
          <div className="text-center py-12 text-amber-200">
            <p>در حال بارگذاری معماهای مرحله...</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="w-full py-3 text-center text-xs text-amber-300/80 border-t border-amber-800/80 bg-[#1d0b02]">
        <div className="max-w-xl mx-auto px-4 flex items-center justify-center">
          <div className="text-amber-400/90 text-xs font-medium">
            آموزش بازی‌محور جدول ضرب ۱ تا ۱۰ با مرحله ویژه قهرمانان
          </div>
        </div>
      </footer>

      {/* Celebration Modal (When 100% correct in any stage) */}
      {showCelebration && (
        <CelebrationModal
          level={currentLevel}
          totalLevels={11}
          onNextLevel={handleNextLevel}
          onReplayLevel={handleReplayLevel}
          onOpenMap={() => {
            setShowCelebration(false);
            setShowLevelSelect(true);
          }}
        />
      )}

      {/* Failure / Retry Modal (When at least 1 mistake occurred) */}
      {showFailure && (
        <FailureModal
          level={currentLevel}
          wrongCount={wrongCount}
          correctCount={correctCount}
          onRetry={handleReplayLevel}
          onOpenMap={() => {
            setShowFailure(false);
            setShowLevelSelect(true);
          }}
        />
      )}
    </div>
  );
}
