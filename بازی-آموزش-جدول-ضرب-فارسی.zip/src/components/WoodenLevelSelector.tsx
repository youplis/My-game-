import React, { useState } from 'react';
import { Check, Star, Sparkles, Play, ShieldCheck, X, Volume2, Store, HelpCircle } from 'lucide-react';
import { STORY_REALMS, StoryRealm, getStoryRealm } from '../utils/gameLogic';
import { toPersianDigits } from '../utils/persianNumbers';
import { soundManager } from '../utils/soundEffects';
import { GoldenPadlock } from './GoldenPadlock';
import { StageVisualSymbol } from './StageVisualSymbol';

interface WoodenLevelSelectorProps {
  unlockedLevels: number;
  completedLevels: number[];
  currentLevel: number;
  totalStars: number;
  onSelectLevel: (lvl: number) => void;
  onOpenRules?: () => void;
}

export const WoodenLevelSelector: React.FC<WoodenLevelSelectorProps> = ({
  unlockedLevels,
  completedLevels,
  currentLevel,
  totalStars,
  onSelectLevel,
  onOpenRules,
}) => {
  const [selectedRealm, setSelectedRealm] = useState<StoryRealm | null>(null);
  const [lockedNotice, setLockedNotice] = useState<string | null>(null);

  const handleStageClick = (realm: StoryRealm) => {
    if (realm.level <= unlockedLevels) {
      soundManager.playClick();
      setSelectedRealm(realm);
    } else {
      soundManager.playWrong();
      setLockedNotice(`مرحله ${toPersianDigits(realm.level)} قفل است! برای باز شدن، ابتدا مرحله قبل را ۱۰۰٪ درست کامل کنید.`);
      setTimeout(() => setLockedNotice(null), 3500);
    }
  };

  const handleStartGame = (level: number) => {
    soundManager.playClick();
    setSelectedRealm(null);
    onSelectLevel(level);
  };

  return (
    <div className="w-full max-w-xl mx-auto flex flex-col items-center select-none px-2 sm:px-4 py-2">
      {/* Top Section: Character peeking over the carved wooden sign, matching the screenshot */}
      <div className="relative w-full flex flex-col items-center pt-2 pb-3">
        {/* User's Daughter Character Mascot peeking above the wooden sign board */}
        <div className="relative z-10 -mb-5 flex flex-col items-center">
          <div className="relative group cursor-pointer" onClick={() => soundManager.playClick()}>
            {/* Ambient golden halo glow */}
            <div className="absolute -inset-1.5 bg-gradient-to-tr from-amber-400 to-yellow-300 rounded-full blur-sm opacity-70 animate-pulse pointer-events-none" />

            {/* Daughter Character Avatar Photo */}
            <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full overflow-hidden border-4 border-amber-300 shadow-[0_8px_16px_rgba(0,0,0,0.6)] bg-amber-100">
              <img
                src="/daughter_avatar.jpg"
                alt="دختر قهرمان جدول ضرب"
                className="w-full h-full object-cover object-center transform group-hover:scale-105 transition-transform duration-300"
                onError={(e) => {
                  // fallback if image takes a second to load
                  e.currentTarget.src = '/daughter_avatar.jpg';
                }}
              />
            </div>

            {/* Cheerful greeting badge */}
            <div className="absolute -bottom-1 -left-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow-md border border-purple-300 flex items-center gap-1">
              <span>✨ قهرمان من</span>
            </div>
          </div>
        </div>

        {/* Carved Wooden Title Sign Board (like the wooden "بازی سمساری" board in screenshot) */}
        <div className="relative z-20 w-full max-w-md wood-sign rounded-2xl p-3 sm:p-4 text-center border-3 border-amber-600">
          {/* 4 Corner Brass Rivets */}
          <div className="absolute top-2 right-2.5 w-2 h-2 rounded-full bg-yellow-400 border border-amber-800 shadow-inner" />
          <div className="absolute top-2 left-2.5 w-2 h-2 rounded-full bg-yellow-400 border border-amber-800 shadow-inner" />
          <div className="absolute bottom-2 right-2.5 w-2 h-2 rounded-full bg-yellow-400 border border-amber-800 shadow-inner" />
          <div className="absolute bottom-2 left-2.5 w-2 h-2 rounded-full bg-yellow-400 border border-amber-800 shadow-inner" />

          {/* Wooden sign title */}
          <h1 className="text-xl sm:text-2xl font-black gold-embossed-text tracking-wide leading-tight">
            بازی جدول ضرب
          </h1>
        </div>
      </div>

      {/* Floating Locked Alert Notification */}
      {lockedNotice && (
        <div className="w-full max-w-md mb-3 bg-gradient-to-r from-rose-900/95 via-rose-800/95 to-amber-900/95 text-amber-100 text-xs font-bold p-3 rounded-2xl border-2 border-rose-500 shadow-lg text-center animate-shake flex items-center justify-between gap-2">
          <span>{lockedNotice}</span>
          <button onClick={() => setLockedNotice(null)} className="p-1 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 4-Column Stages Grid matching the user's mobile game screenshot */}
      <div className="w-full max-w-md grid grid-cols-4 gap-2.5 sm:gap-3.5 my-3">
        {STORY_REALMS.map((realm) => {
          const isUnlocked = realm.level <= unlockedLevels;
          const isCompleted = completedLevels.includes(realm.level);
          const isCurrent = realm.level === unlockedLevels;

          return (
            <div
              key={realm.level}
              className="flex flex-col items-center"
              onClick={() => handleStageClick(realm)}
            >
              {/* Wooden Square Card */}
              <div
                className={`
                  stage-card-wood relative w-full aspect-square rounded-2xl p-1.5 flex items-center justify-center cursor-pointer
                  ${
                    isCurrent && isUnlocked
                      ? 'ring-3 ring-amber-300 ring-offset-2 ring-offset-amber-950 scale-[1.03]'
                      : ''
                  }
                  ${!isUnlocked ? 'opacity-85' : 'hover:scale-105'}
                `}
              >
                {/* 4 Corner Studs */}
                <div className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-amber-300/70" />
                <div className="absolute top-1 left-1 w-1.5 h-1.5 rounded-full bg-amber-300/70" />
                <div className="absolute bottom-1 right-1 w-1.5 h-1.5 rounded-full bg-amber-300/70" />
                <div className="absolute bottom-1 left-1 w-1.5 h-1.5 rounded-full bg-amber-300/70" />

                {/* Recessed Center Area */}
                <div className="stage-card-inner w-full h-full rounded-xl flex items-center justify-center relative overflow-hidden">
                  {!isUnlocked ? (
                    /* Locked State: Golden Padlock matching the screenshot */
                    <GoldenPadlock className="w-9 h-11 sm:w-10 sm:h-12" />
                  ) : (
                    /* Unlocked State: Visual Stage Symbol Emblem */
                    <StageVisualSymbol level={realm.level} />
                  )}

                  {/* Green Checkmark Badge when Completed (exactly matching the user's screenshot) */}
                  {isCompleted && (
                    <div className="badge-checkmark absolute bottom-1 left-1 w-5 h-5 rounded-full flex items-center justify-center z-10">
                      <Check className="w-3.5 h-3.5 text-white stroke-[3.5]" />
                    </div>
                  )}

                  {/* Current Active Pulsing Beacon */}
                  {isCurrent && isUnlocked && !isCompleted && (
                    <div className="absolute top-1 right-1">
                      <span className="relative flex h-2.5 w-2.5">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
                        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500" />
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Wooden Label Underneath: "مرحله ۱", "مرحله ۲", ... */}
              <div className="stage-label-wood mt-1 px-2 py-0.5 rounded-lg text-[11px] sm:text-xs font-bold text-center w-full max-w-[85%] truncate">
                مرحله {toPersianDigits(realm.level)}
              </div>
            </div>
          );
        })}
      </div>

      {/* Pagination Carousel Dots matching the bottom of the user's screenshot */}
      <div className="flex items-center justify-center gap-2 mt-3 mb-2">
        <div className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-[0_0_8px_#f59e0b]" />
        <div className="w-2 h-2 rounded-full bg-amber-950 border border-amber-700/60" />
        <div className="w-2 h-2 rounded-full bg-amber-950 border border-amber-700/60" />
        <div className="w-2 h-2 rounded-full bg-amber-950 border border-amber-700/60" />
        <div className="w-2 h-2 rounded-full bg-amber-950 border border-amber-700/60" />
        <div className="w-2 h-2 rounded-full bg-amber-950 border border-amber-700/60" />
      </div>

      {/* Quick Play Action Bar */}
      <div className="w-full max-w-md mt-2 flex items-center justify-between gap-3 bg-amber-950/70 border-2 border-amber-800/80 rounded-2xl p-2.5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
          </div>
          <div className="text-xs">
            <span className="text-amber-200/80">مرحله آماده بازی: </span>
            <strong className="text-yellow-300 font-black">
              مرحله {toPersianDigits(Math.min(unlockedLevels, 11))} ({getStoryRealm(Math.min(unlockedLevels, 11)).name})
            </strong>
          </div>
        </div>

        <button
          onClick={() => handleStartGame(Math.min(unlockedLevels, 11))}
          className="btn-3d py-2 px-4 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-amber-950 font-black text-xs rounded-xl shadow-[0_3px_0_#b45309] flex items-center gap-1.5 cursor-pointer active:translate-y-0.5"
        >
          <Play className="w-3.5 h-3.5 fill-amber-950" />
          <span>ورود به بازی</span>
        </button>
      </div>

      {/* Stage Detail & Mission Modal when an unlocked stage is clicked */}
      {selectedRealm && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4">
          <div className="wood-board rounded-3xl p-5 sm:p-6 max-w-sm w-full shadow-2xl text-center relative overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Close button */}
            <button
              onClick={() => setSelectedRealm(null)}
              className="absolute top-3 left-3 w-8 h-8 rounded-full bg-amber-900/80 text-amber-200 hover:text-white flex items-center justify-center border border-amber-700 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Stage Visual Symbol */}
            <div className="w-20 h-20 stage-card-wood rounded-2xl mx-auto flex items-center justify-center shadow-lg border-2 border-amber-500 mb-3">
              <StageVisualSymbol level={selectedRealm.level} />
            </div>

            {/* Stage Title Badge */}
            <div className="inline-block bg-amber-500/20 text-yellow-300 text-xs font-black px-3 py-1 rounded-xl border border-amber-500/40 mb-1">
              مرحله {toPersianDigits(selectedRealm.level)}: {selectedRealm.name}
            </div>

            <h3 className="text-lg font-black text-white mt-1 mb-2">
              {selectedRealm.themeLabel}
            </h3>

            {/* Story & Mission Box */}
            <div className="bg-black/35 border border-amber-800/80 rounded-2xl p-3 text-right text-xs leading-relaxed text-amber-100 mb-4 space-y-2">
              <p className="text-amber-200 font-medium">
                {selectedRealm.story}
              </p>
              <div className="pt-2 border-t border-amber-900/60 flex items-center gap-1.5 text-yellow-300 font-bold">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>قانون: ۱۰ سوال بدون حتی ۱ غلط برای عبور به مرحله بعد</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleStartGame(selectedRealm.level)}
                className="btn-3d flex-1 py-3 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black text-sm rounded-xl shadow-[0_4px_0_#065f46] flex items-center justify-center gap-2 cursor-pointer active:translate-y-1"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>شروع آزمون این مرحله</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
