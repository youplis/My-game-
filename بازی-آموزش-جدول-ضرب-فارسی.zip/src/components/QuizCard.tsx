import React, { useState, useEffect } from 'react';
import { Volume2, Check, X, CheckCircle2, XCircle, Grid, Sparkles } from 'lucide-react';
import { Question, getStoryRealm } from '../utils/gameLogic';
import { toPersianDigits, numberToPersianWords } from '../utils/persianNumbers';
import { soundManager } from '../utils/soundEffects';
import { triggerCorrectSparkle } from '../utils/confettiFireworks';
import { StageVisualSymbol } from './StageVisualSymbol';

interface QuizCardProps {
  question: Question;
  questionIndex: number;
  totalQuestions: number;
  currentLevel: number;
  wrongCount: number;
  correctCount: number;
  onAnswer: (chosenAnswer: number) => void;
  onOpenMap: () => void;
}

const card3dClasses = [
  'btn-3d-card-amber',
  'btn-3d-card-emerald',
  'btn-3d-card-purple',
  'btn-3d-card-indigo',
];

export const QuizCard: React.FC<QuizCardProps> = ({
  question,
  questionIndex,
  totalQuestions,
  currentLevel,
  wrongCount,
  correctCount,
  onAnswer,
  onOpenMap,
}) => {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);

  const realm = getStoryRealm(currentLevel);

  useEffect(() => {
    setSelectedAnswer(null);
    setIsAnswered(false);
  }, [question.id]);

  const handleSelect = (option: number, event: React.MouseEvent<HTMLButtonElement>) => {
    if (isAnswered) return;

    setSelectedAnswer(option);
    setIsAnswered(true);

    const isCorrect = option === question.answer;

    if (isCorrect) {
      soundManager.playCorrect();
      const rect = event.currentTarget.getBoundingClientRect();
      const originX = (rect.left + rect.width / 2) / window.innerWidth;
      const originY = (rect.top + rect.height / 2) / window.innerHeight;
      triggerCorrectSparkle(originX, originY);
    } else {
      soundManager.playWrong();
    }

    setTimeout(() => {
      onAnswer(option);
    }, 750);
  };

  const handleSpeakQuestion = () => {
    soundManager.playClick();
    const textToSpeak = `${numberToPersianWords(question.num1)} ضرب در ${numberToPersianWords(question.num2)} چند می‌شود؟`;
    soundManager.speakPersian(textToSpeak);
  };

  return (
    <div className="w-full max-w-xl mx-auto flex flex-col items-center">
      {/* City/Realm Title Bar & Return to Stages */}
      <div className="w-full mb-3 flex items-center justify-between px-3 sm:px-4 py-2 wood-sign rounded-2xl border-2 border-amber-600 shadow-md">
        <div className="flex items-center gap-2.5">
          <div className="w-11 h-11 rounded-xl bg-black/45 border border-amber-400/60 flex items-center justify-center p-1 shadow-inner">
            <StageVisualSymbol level={currentLevel} showBadge={false} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-black text-amber-950 bg-gradient-to-r from-yellow-300 to-amber-400 px-2 py-0.5 rounded-md shadow-2xs border border-yellow-200">
                {currentLevel === 11 ? 'مرحله پایانی' : `مرحله ${toPersianDigits(currentLevel)}`}
              </span>
              <span className="text-xs font-bold text-amber-200">{realm.badge}</span>
            </div>
            <h2 className="text-sm font-black text-white leading-tight mt-0.5">
              {realm.name} ({realm.themeLabel})
            </h2>
          </div>
        </div>

        {/* Back to Stages List Button */}
        <button
          onClick={() => {
            soundManager.playClick();
            onOpenMap();
          }}
          className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-amber-100 bg-[#512307] hover:bg-[#6a2f09] rounded-xl border border-amber-600 shadow-[0_2px_0_#230c02] active:translate-y-0.5 transition-all cursor-pointer"
        >
          <Grid className="w-4 h-4 text-amber-300" />
          <span>مراحل</span>
        </button>
      </div>

      {/* Character Mascot & Encouragement Speech Bubble */}
      <div className="w-full mb-2 sm:mb-3 flex items-center gap-2 sm:gap-3 px-1 sm:px-2">
        {/* Daughter Character Avatar Photo */}
        <div className="relative w-13 h-13 sm:w-16 sm:h-16 rounded-full overflow-hidden border-2 sm:border-3 border-amber-300 shadow-md bg-amber-100 shrink-0">
          <img
            src="/daughter_avatar.jpg"
            alt="دختر قهرمان جدول ضرب"
            className="w-full h-full object-cover object-center"
          />
        </div>

        {/* Speech Bubble */}
        <div className="relative flex-1 bg-gradient-to-r from-amber-100 to-yellow-50 text-slate-800 rounded-xl sm:rounded-2xl p-2 sm:p-3 text-[11px] sm:text-sm font-bold shadow-md border-2 border-amber-300">
          <div className="flex items-center justify-between gap-1.5">
            <span className="truncate">
              {isAnswered
                ? selectedAnswer === question.answer
                  ? 'آفرین قهرمان! پاسخ کاملاً درسته! 🌟'
                  : 'اشکال نداره عزیزم، دوباره دقت کن! 💪'
                : 'با دقت فکر کن و پاسخ درست رو انتخاب کن! 🎯'}
            </span>
            <span className="text-[9px] sm:text-[10px] text-amber-900 bg-amber-200/80 px-1.5 sm:px-2 py-0.5 rounded-lg shrink-0 font-extrabold">
              {toPersianDigits(questionIndex + 1)} از ۱۰
            </span>
          </div>
        </div>
      </div>

      {/* Score & Status Bar */}
      <div className="w-full mb-2.5 sm:mb-3.5 flex items-center justify-between px-2.5 sm:px-4 py-1.5 sm:py-2 bg-black/60 rounded-xl sm:rounded-2xl border border-amber-800/80 shadow-inner">
        {/* Correct Answers Counter */}
        <div className="flex items-center gap-1.5 px-2.5 py-0.5 sm:px-3 sm:py-1 bg-gradient-to-b from-emerald-950 to-emerald-900 text-emerald-300 rounded-lg sm:rounded-xl border border-emerald-500 shadow-2xs font-bold text-xs sm:text-sm">
          <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-400" />
          <span>درست:</span>
          <span className="tabular-nums text-emerald-200 text-xs sm:text-base font-black mr-0.5">
            {toPersianDigits(correctCount)}
          </span>
        </div>

        {/* Wrong Answers Counter */}
        <div
          className={`flex items-center gap-1.5 px-2.5 py-0.5 sm:px-3 sm:py-1 rounded-lg sm:rounded-xl border font-bold text-xs sm:text-sm transition-all shadow-2xs ${
            wrongCount > 0
              ? 'bg-gradient-to-b from-rose-950 to-rose-900 text-rose-300 border-rose-500 animate-pulse'
              : 'bg-gradient-to-b from-[#3a1805] to-[#250e03] text-amber-300 border-amber-800'
          }`}
        >
          <XCircle className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${wrongCount > 0 ? 'text-rose-400' : 'text-amber-500/70'}`} />
          <span>خطا:</span>
          <span className="tabular-nums text-xs sm:text-base font-black mr-0.5">
            {toPersianDigits(wrongCount)}
          </span>
        </div>
      </div>

      {/* Main Game Screen matching screenshot with 3D tactile polish */}
      <div className="w-full wood-board rounded-2xl sm:rounded-3xl p-4 sm:p-7 shadow-2xl flex flex-col items-center relative overflow-hidden">
        {/* Ambient warm light accents */}
        <div className="absolute -top-24 -right-24 w-52 h-52 bg-amber-400/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-52 h-52 bg-yellow-400/15 rounded-full blur-3xl pointer-events-none" />

        {/* 3D Speaker Button */}
        <div className="relative mb-3 sm:mb-4">
          <button
            onClick={handleSpeakQuestion}
            className="w-13 h-10 sm:w-16 sm:h-13 rounded-xl sm:rounded-2xl flex items-center justify-center transition-all cursor-pointer group btn-3d
              bg-gradient-to-b from-amber-500 via-amber-600 to-yellow-700 border-2 border-amber-300
              shadow-[0_4px_0_#451a03,0_8px_12px_rgba(245,158,11,0.35)] active:translate-y-1 active:shadow-[0_1px_0_#451a03]"
            title="شنیدن سوال به زبان فارسی"
            aria-label="شنیدن سوال به زبان فارسی"
          >
            <Volume2 className="w-5 h-5 sm:w-7 sm:h-7 text-yellow-100 drop-shadow-sm group-hover:scale-110 transition-transform" />
          </button>
        </div>

        {/* 
          Big Mathematical Question:
          Left-to-right math layout (num1 is the stage number, e.g. 2, strictly on the left)
        */}
        <div className="mb-4 sm:mb-6 text-center select-none w-full">
          <div
            dir="ltr"
            className="text-5xl sm:text-7xl font-black text-white tracking-wider flex items-center justify-center gap-2 sm:gap-5 drop-shadow-[0_4px_12px_rgba(0,0,0,0.85)]"
          >
            {/* Stage Number (e.g. 2) strictly on the left */}
            <span className="tabular-nums text-amber-300 drop-shadow-[0_2px_8px_rgba(251,191,36,0.7)]">
              {toPersianDigits(question.num1)}
            </span>

            {/* Multiplication Symbol */}
            <span className="text-4xl sm:text-6xl text-amber-400 font-extrabold px-0.5 sm:px-1">
              ×
            </span>

            {/* Multiplier (1 to 10) */}
            <span className="tabular-nums text-white">
              {toPersianDigits(question.num2)}
            </span>

            {/* Equal Sign */}
            <span className="text-3xl sm:text-5xl text-amber-400 font-bold px-0.5 sm:px-1">
              =
            </span>

            {/* Question Mark */}
            <span className="text-3xl sm:text-5xl text-yellow-300 font-black animate-pulse">
              ؟
            </span>
          </div>

          {/* Persian Subtitle Guide */}
          <div className="mt-2 sm:mt-3 inline-flex items-center gap-1.5 px-3 py-0.5 sm:py-1 rounded-full bg-black/45 border border-amber-400/50 text-amber-200 text-[11px] sm:text-sm font-bold shadow-inner">
            <Sparkles className="w-3 h-3 text-yellow-300 shrink-0" />
            <span>
              ضرب {toPersianDigits(question.num1)}: {toPersianDigits(question.num1)} ضرب‌در {toPersianDigits(question.num2)}
            </span>
          </div>
        </div>

        {/* 4 Large 3D Option Cards (2x2 Grid) with vibrant glowing candy colors */}
        <div className="w-full grid grid-cols-2 gap-2.5 sm:gap-4 select-none">
          {question.options.map((option, idx) => {
            const baseClass = card3dClasses[idx % card3dClasses.length];
            const isSelected = selectedAnswer === option;
            const isCorrect = option === question.answer;

            let stateClass = baseClass;

            if (isAnswered) {
              if (isSelected) {
                stateClass = isCorrect ? 'btn-3d-correct' : 'btn-3d-wrong';
              } else if (isCorrect) {
                stateClass = 'btn-3d-correct ring-3 sm:ring-4 ring-emerald-300 ring-offset-2';
              } else {
                stateClass = 'opacity-25 bg-slate-800 border-slate-700 text-slate-500 shadow-none';
              }
            }

            return (
              <button
                key={idx}
                disabled={isAnswered}
                onClick={(e) => handleSelect(option, e)}
                className={`
                  btn-3d relative h-20 sm:h-26 rounded-xl sm:rounded-2xl font-black text-3xl sm:text-5xl
                  flex items-center justify-center cursor-pointer disabled:cursor-default
                  ${stateClass}
                  ${isSelected && !isCorrect ? 'animate-shake' : ''}
                `}
              >
                <span className="tabular-nums drop-shadow-sm font-black">
                  {toPersianDigits(option)}
                </span>

                {/* 3D Indicator Badge on answer */}
                {isAnswered && isSelected && isCorrect && (
                  <div className="absolute bottom-1.5 left-2 bg-emerald-900/90 border border-emerald-300 text-white rounded-full p-0.5 sm:p-1 shadow-sm">
                    <Check className="w-4 h-4 text-emerald-100 stroke-[3.5]" />
                  </div>
                )}
                {isAnswered && isSelected && !isCorrect && (
                  <div className="absolute bottom-1.5 left-2 bg-rose-900/90 border border-rose-300 text-white rounded-full p-0.5 sm:p-1 shadow-sm">
                    <X className="w-4 h-4 text-rose-100 stroke-[3.5]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom Progress Bar */}
        <div className="w-full mt-7 pt-4 border-t border-amber-800/80 flex items-center justify-between text-xs sm:text-sm text-amber-200/80 font-medium">
          <div className="flex items-center gap-1.5">
            <span>پیشرفت سوالات:</span>
          </div>

          {/* Progress indicators dots */}
          <div className="flex items-center gap-1.5">
            {Array.from({ length: totalQuestions }).map((_, i) => (
              <div
                key={i}
                className={`h-2.5 rounded-full transition-all duration-300 ${
                  i === questionIndex
                    ? 'w-7 bg-yellow-400 shadow-md'
                    : i < questionIndex
                    ? 'w-2.5 bg-emerald-400'
                    : 'w-2.5 bg-amber-950 border border-amber-800'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
