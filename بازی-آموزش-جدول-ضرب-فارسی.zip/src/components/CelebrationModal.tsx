import React, { useEffect } from 'react';
import { Trophy, ArrowLeft, RotateCcw, Award, Grid } from 'lucide-react';
import { toPersianDigits } from '../utils/persianNumbers';
import { triggerVictoryConfetti } from '../utils/confettiFireworks';
import { soundManager } from '../utils/soundEffects';
import { getStoryRealm } from '../utils/gameLogic';
import { StageVisualSymbol } from './StageVisualSymbol';

interface CelebrationModalProps {
  level: number;
  totalLevels: number;
  onNextLevel: () => void;
  onReplayLevel: () => void;
  onOpenMap: () => void;
}

export const CelebrationModal: React.FC<CelebrationModalProps> = ({
  level,
  totalLevels,
  onNextLevel,
  onReplayLevel,
  onOpenMap,
}) => {
  const currentRealm = getStoryRealm(level);
  const nextLevelNumber = level + 1;
  const nextRealm = nextLevelNumber <= totalLevels ? getStoryRealm(nextLevelNumber) : null;
  const isFinalLevel = level >= totalLevels;

  useEffect(() => {
    // Gentle melodic chime once
    soundManager.playVictoryFanfare();
    // Brief single graceful sparkle burst
    triggerVictoryConfetti();
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85">
      <div className="relative w-full max-w-sm wood-board rounded-3xl p-5 sm:p-6 shadow-2xl text-center border-3 border-amber-400/90 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Subtle luminous ambient glow */}
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-amber-400/20 rounded-full blur-xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-emerald-400/15 rounded-full blur-xl pointer-events-none" />

        {/* Mascot & Crown Badge */}
        <div className="relative z-10 flex flex-col items-center mb-2">
          <div className="relative">
            <div className="w-20 h-20 sm:w-22 sm:h-22 rounded-full overflow-hidden border-3 border-amber-300 shadow-xl bg-amber-100">
              <img
                src="/daughter_avatar.jpg"
                alt="دختر قهرمان جدول ضرب"
                className="w-full h-full object-cover object-center"
              />
            </div>

            {/* Glowing 3D Checkmark Trophy */}
            <div className="badge-checkmark absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center shadow-lg border-2 border-white">
              <Trophy className="w-3.5 h-3.5 text-yellow-100" />
            </div>
          </div>
        </div>

        {/* Header Tag */}
        <div className="inline-block bg-gradient-to-r from-amber-400 to-yellow-400 text-amber-950 font-black text-xs px-3 py-0.5 rounded-full shadow-xs mb-1.5">
          {isFinalLevel ? '★ قهرمان کل جدول ضرب ★' : `پیروزی در ضرب عدد ${toPersianDigits(level)}`}
        </div>

        <h2 className="text-xl sm:text-2xl font-black text-white drop-shadow-md mb-1">
          {isFinalLevel ? 'آفرین! شما استاد جدول ضرب شدید!' : 'مرحله با موفقیت فتح شد! 🌟'}
        </h2>

        <p className="text-xs text-amber-200/90 font-medium mb-3">
          ۱۰ پاسخ صحیح متوالی با نمره ۱۰۰٪ و بدون خطا
        </p>

        {/* Next Unlocked Realm Badge Preview */}
        {nextRealm && (
          <div className="bg-black/50 border border-amber-600/80 rounded-2xl p-2.5 mb-4 flex items-center justify-between text-right">
            <div className="flex items-center gap-2.5">
              <div className="w-11 h-11 stage-card-wood rounded-xl flex items-center justify-center shadow-md border border-amber-400">
                <StageVisualSymbol level={nextRealm.level} showBadge={false} />
              </div>
              <div>
                <div className="text-[10px] text-yellow-300 font-bold">قفل مرحله بعد باز شد:</div>
                <div className="text-xs font-black text-white">
                  مرحله {toPersianDigits(nextRealm.level)} ({nextRealm.name})
                </div>
              </div>
            </div>

            <div className="bg-emerald-500 text-white text-[10px] font-black px-2.5 py-1 rounded-lg shadow-xs">
              باز شد ✓
            </div>
          </div>
        )}

        {/* Fast Action Buttons */}
        <div className="space-y-2 select-none">
          {!isFinalLevel ? (
            <button
              onClick={() => {
                soundManager.playClick();
                onNextLevel();
              }}
              className="btn-3d w-full py-3 px-4 bg-gradient-to-r from-emerald-500 via-emerald-600 to-teal-600 hover:brightness-110 text-white font-black text-sm rounded-xl shadow-[0_4px_0_#065f46,0_6px_12px_rgba(16,185,129,0.35)] flex items-center justify-center gap-2 cursor-pointer active:translate-y-1"
            >
              <span>رفتن به مرحله بعدی</span>
              <ArrowLeft className="w-4 h-4 stroke-[3]" />
            </button>
          ) : (
            <button
              onClick={() => {
                soundManager.playClick();
                onOpenMap();
              }}
              className="btn-3d w-full py-3 px-4 bg-gradient-to-r from-amber-400 to-yellow-500 hover:brightness-110 text-amber-950 font-black text-sm rounded-xl shadow-[0_4px_0_#b45309,0_6px_12px_rgba(245,158,11,0.35)] flex items-center justify-center gap-2 cursor-pointer active:translate-y-1"
            >
              <Trophy className="w-4 h-4 fill-amber-950" />
              <span>بازگشت به تابلوی مراحل</span>
            </button>
          )}

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                soundManager.playClick();
                onOpenMap();
              }}
              className="btn-3d py-2 px-3 bg-[#512307] hover:bg-[#682e0a] text-amber-100 font-bold text-xs rounded-xl border border-amber-600 shadow-[0_2.5px_0_#230c02] flex items-center justify-center gap-1 cursor-pointer active:translate-y-0.5"
            >
              <Grid className="w-3.5 h-3.5 text-amber-300" />
              <span>لیست مراحل</span>
            </button>

            <button
              onClick={() => {
                soundManager.playClick();
                onReplayLevel();
              }}
              className="btn-3d py-2 px-3 bg-[#512307] hover:bg-[#682e0a] text-amber-100 font-bold text-xs rounded-xl border border-amber-600 shadow-[0_2.5px_0_#230c02] flex items-center justify-center gap-1 cursor-pointer active:translate-y-0.5"
            >
              <RotateCcw className="w-3.5 h-3.5 text-amber-300" />
              <span>تکرار مجدد</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
