import React, { useState, useEffect } from 'react';
import { Download, CheckCircle, AlertCircle, X, Smartphone, Sparkles, Loader2 } from 'lucide-react';

export const PreviewDownloadBanner: React.FC = () => {
  const [isPortable, setIsPortable] = useState<boolean>(true);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDismissed, setIsDismissed] = useState<boolean>(false);

  useEffect(() => {
    // Check if running as portable standalone or via file:// protocol
    const checkIsPortable =
      typeof window !== 'undefined' &&
      Boolean(
        (window as any).__IS_PORTABLE__ ||
        window.location.protocol === 'file:' ||
        window.location.pathname.endsWith('jadval-zarb-portable.html')
      );
    setIsPortable(checkIsPortable);
  }, []);

  // DO NOT RENDER anything if running inside the portable file!
  if (isPortable || isDismissed) {
    return null;
  }

  const handleDownload = async () => {
    setIsDownloading(true);
    setErrorMessage(null);
    try {
      // Fetch the portable HTML file directly from the preview server
      const response = await fetch('/jadval-zarb-portable.html', {
        cache: 'no-cache',
      });

      if (!response.ok) {
        throw new Error(`خطا در دریافت فایل (${response.status})`);
      }

      const blob = await response.blob();
      // Create local Blob URL to guarantee real file download without redirects or cookie issues
      const blobUrl = URL.createObjectURL(blob);
      const downloadLink = document.createElement('a');
      downloadLink.href = blobUrl;
      downloadLink.download = 'jadval-zarb-portable.html';
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);

      // Clean up blob URL after delay
      setTimeout(() => {
        URL.revokeObjectURL(blobUrl);
      }, 30000);

      setDownloadSuccess(true);
    } catch (err: any) {
      console.error('Download error:', err);
      // Fallback: direct window location
      setErrorMessage('دانلود مستقیم انجام نشد، در حال انتقال به لینک دانلود...');
      window.location.href = '/jadval-zarb-portable.html';
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="w-full bg-gradient-to-r from-emerald-950 via-teal-950 to-emerald-900 border-b-2 border-emerald-500/80 px-3 py-2.5 shadow-xl text-emerald-100 z-40 relative">
      <div className="max-w-xl mx-auto flex flex-col gap-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center shrink-0">
              <Smartphone className="w-4 h-4 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-white">دانلود نسخه پرتابل تک‌فایلی مخصوص موبایل</span>
                <span className="text-[10px] bg-emerald-500/30 text-emerald-200 border border-emerald-400/40 px-1.5 py-0.2 rounded-full font-bold">
                  آفلاین
                </span>
              </div>
              <p className="text-[11px] text-emerald-200/90 leading-tight mt-0.5">
                فایل بدون نیاز به اینترنت و بدون مشکل کوکی، مستقیماً در مرورگر موبایل شما اجرا می‌شود.
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsDismissed(true)}
            className="text-emerald-300/70 hover:text-white p-1 rounded-lg hover:bg-emerald-800/40 transition-colors cursor-pointer"
            title="بستن این کادر"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-2 mt-0.5">
          <button
            onClick={handleDownload}
            disabled={isDownloading}
            className="flex-1 btn-3d py-2 px-3 bg-gradient-to-r from-emerald-500 via-emerald-600 to-teal-600 hover:brightness-110 active:brightness-95 text-white font-extrabold text-xs rounded-xl shadow-[0_2.5px_0_#064e3b] flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            {isDownloading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-emerald-100" />
                <span>در حال آماده‌سازی فایل دانلود...</span>
              </>
            ) : downloadSuccess ? (
              <>
                <CheckCircle className="w-4 h-4 text-emerald-200" />
                <span>فایل دانلود شد! (دانلود مجدد)</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 text-white stroke-[2.5]" />
                <span>کلیک کنید: دانلود فایل jadval-zarb-portable.html</span>
              </>
            )}
          </button>
        </div>

        {downloadSuccess && (
          <div className="bg-emerald-900/60 border border-emerald-400/50 rounded-lg p-1.5 text-[11px] text-emerald-200 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
            <span>فایل در پوشه Downloads گوشی شما قرار گرفت. با زدن روی آن، بازی آفلاین باز می‌شود.</span>
          </div>
        )}

        {errorMessage && (
          <div className="bg-rose-900/60 border border-rose-400/50 rounded-lg p-1.5 text-[11px] text-rose-200 flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-rose-300 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
      </div>
    </div>
  );
};
