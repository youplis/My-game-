import React from 'react';
import { RotateCcw, Grid, Award } from 'lucide-react';
import { toPersianDigits } from '../utils/persianNumbers';
import { getStoryRealm } from '../utils/gameLogic';
import { soundManager } from '../utils/soundEffects';

interface FailureModalProps {
  level: number;
  wrongCount: number;
  correctCount: number;
  onRetry: () => void;
  onOpenMap: () => void;
}

export const FailureModal: React.FC<FailureModalProps> = ({
  level,
  wrongCount,
  correctCount,
  onRetry,
  onOpenMap,
}) => {
  const realm = getStoryRealm(level);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/90 overflow-y-auto">
      <div className="relative w-full max-w-md wood-board rounded-3xl p-5 sm:p-6 shadow-2xl text-center border-4 border-amber-800/80 overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-auto">
        {/* Character Avatar Encouraging the child */}
        <div className="relative z-10 flex flex-col items-center -mt-2 mb-3">
          <div className="relative">
            <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden border-4 border-amber-400 shadow-xl bg-amber-100">
              <img
                src="/daughter_avatar.jpg"
                alt="دختر قهرمان جدول ضرب"
                className="w-full h-full object-cover object-center"
              />
            </div>

            {/* Kind encouragement badge */}
            <div className="absolute -bottom-1 -left-2 bg-gradient-to-r from-amber-600 to-amber-700 text-white text-[10px] font-black px-2.5 py-1 rounded-full shadow-md border border-amber-300">
              دوباره امتحان کن! 🌸
            </div>
          </div>
        </div>

        {/* Title */}
        <h2 className="text-xl sm:text-2xl font-black text-white drop-shadow-md mb-1">
          نیاز به تلاش دوباره
        </h2>

        <p className="text-xs sm:text-sm text-amber-200/90 font-medium mb-4">
          برای عبور به مرحله بالاتر، باید به تمام سوالات بدون هیچ خطایی پاسخ دهید.
        </p>

        {/* Stats Box showing exact wrong and correct counts cleanly */}
        <div className="bg-black/45 border border-amber-800/80 rounded-2xl p-3.5 mb-4 grid grid-cols-2 gap-3 text-center">
          <div className="bg-emerald-950/60 border border-emerald-700/60 rounded-xl p-2">
            <div className="text-[11px] text-emerald-300 font-bold mb-0.5">پاسخ‌های درست</div>
            <div className="text-2xl font-black text-emerald-200 tabular-nums">
              {toPersianDigits(correctCount)}
            </div>
          </div>

          <div className="bg-rose-950/60 border border-rose-700/60 rounded-xl p-2">
            <div className="text-[11px] text-rose-300 font-bold mb-0.5">تعداد پاسخ غلط</div>
            <div className="text-2xl font-black text-rose-200 tabular-nums">
              {toPersianDigits(wrongCount)}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 select-none">
          <button
            onClick={() => {
              soundManager.playClick();
              onRetry();
            }}
            className="btn-3d w-full py-3.5 px-4 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-amber-950 font-black text-sm rounded-xl shadow-[0_5px_0_#b45309] flex items-center justify-center gap-2 cursor-pointer active:translate-y-1"
          >
            <RotateCcw className="w-4 h-4 stroke-[3]" />
            <span>تلاش مجدد در این مرحله</span>
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              onOpenMap();
            }}
            className="btn-3d w-full py-2.5 px-3 bg-[#512307] hover:bg-[#682e0a] text-amber-100 font-bold text-xs rounded-xl border border-amber-600 shadow-[0_3px_0_#230c02] flex items-center justify-center gap-1.5 cursor-pointer active:translate-y-0.5"
          >
            <Grid className="w-3.5 h-3.5 text-amber-300" />
            <span>بازگشت به تابلوی مراحل</span>
          </button>
        </div>
      </div>
    </div>
  );
};
