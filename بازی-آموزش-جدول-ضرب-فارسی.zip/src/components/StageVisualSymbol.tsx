import React from 'react';
import { toPersianDigits } from '../utils/persianNumbers';

interface StageVisualSymbolProps {
  level: number;
  className?: string;
  showBadge?: boolean;
}

export const StageVisualSymbol: React.FC<StageVisualSymbolProps> = ({
  level,
  className = 'w-full h-full',
  showBadge = true,
}) => {
  const renderIcon = () => {
    switch (level) {
      case 1:
        // 3D Glowing Sakura Crystal Blossom (ضرب ۱)
        return (
          <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-12 sm:h-12 drop-shadow-[0_4px_10px_rgba(244,114,182,0.7)]" fill="none">
            <defs>
              <radialGradient id="sakura-core" cx="32" cy="32" r="12" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#fffbeb" />
                <stop offset="50%" stopColor="#fde047" />
                <stop offset="100%" stopColor="#f59e0b" />
              </radialGradient>
              <linearGradient id="sakura-petal-top" x1="32" y1="6" x2="32" y2="30" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#ffb1d8" />
                <stop offset="60%" stopColor="#f43f5e" />
                <stop offset="100%" stopColor="#be123c" />
              </linearGradient>
              <linearGradient id="sakura-petal-glow" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#f472b6" stopOpacity="0" />
              </linearGradient>
            </defs>
            {/* Ambient petal glow halo */}
            <circle cx="32" cy="32" r="22" fill="#f472b6" opacity="0.25" filter="blur(3px)" />
            {/* 5 Petals */}
            {[0, 72, 144, 216, 288].map((angle, idx) => (
              <g key={idx} transform={`rotate(${angle} 32 32)`}>
                <path
                  d="M32 7 C26 14 24 24 32 31 C40 24 38 14 32 7 Z"
                  fill="url(#sakura-petal-top)"
                  stroke="#fda4af"
                  strokeWidth="1.2"
                />
                <ellipse cx="32" cy="18" rx="2.5" ry="6" fill="url(#sakura-petal-glow)" opacity="0.7" />
              </g>
            ))}
            {/* Center golden stamen star */}
            <circle cx="32" cy="32" r="7" fill="url(#sakura-core)" stroke="#fff" strokeWidth="1.5" />
            <circle cx="32" cy="32" r="3" fill="#ffffff" />
            {/* Glint sparkles */}
            <circle cx="30" cy="30" r="1.5" fill="#ffffff" />
            <polygon points="44,14 45,17 48,18 45,19 44,22 43,19 40,18 43,17" fill="#ffffff" opacity="0.9" />
          </svg>
        );

      case 2:
        // 3D Glowing Emerald Crystal Gem (ضرب ۲)
        return (
          <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-12 sm:h-12 drop-shadow-[0_4px_12px_rgba(16,185,129,0.75)]" fill="none">
            <defs>
              <linearGradient id="em-top" x1="32" y1="12" x2="32" y2="24" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#a7f3d0" />
                <stop offset="100%" stopColor="#34d399" />
              </linearGradient>
              <linearGradient id="em-left" x1="12" y1="24" x2="32" y2="52" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#10b981" />
                <stop offset="100%" stopColor="#047857" />
              </linearGradient>
              <linearGradient id="em-center" x1="20" y1="24" x2="44" y2="52" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#34d399" />
                <stop offset="60%" stopColor="#059669" />
                <stop offset="100%" stopColor="#064e3b" />
              </linearGradient>
              <linearGradient id="em-right" x1="32" y1="24" x2="52" y2="52" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#059669" />
                <stop offset="100%" stopColor="#022c22" />
              </linearGradient>
            </defs>
            {/* Emerald ambient halo */}
            <circle cx="32" cy="32" r="22" fill="#10b981" opacity="0.25" filter="blur(3px)" />
            {/* Top crown table facet */}
            <polygon points="22,14 42,14 50,25 14,25" fill="url(#em-top)" stroke="#ecfdf5" strokeWidth="1.2" />
            {/* Center lower pavilion */}
            <polygon points="22,25 32,52 42,25" fill="url(#em-center)" stroke="#a7f3d0" strokeWidth="0.8" />
            {/* Left pavilion */}
            <polygon points="14,25 32,52 22,25" fill="url(#em-left)" stroke="#6ee7b7" strokeWidth="0.8" />
            {/* Right pavilion */}
            <polygon points="42,25 32,52 50,25" fill="url(#em-right)" stroke="#047857" strokeWidth="0.8" />
            {/* Top bevel gloss highlight */}
            <polygon points="25,16 39,16 43,22 21,22" fill="#ffffff" opacity="0.65" />
            {/* Sparkle glint */}
            <polygon points="46,16 47,19 50,20 47,21 46,24 45,21 42,20 45,19" fill="#ffffff" />
            <polygon points="18,34 19,36 21,37 19,38 18,40 17,38 15,37 17,36" fill="#ffffff" opacity="0.8" />
          </svg>
        );

      case 3:
        // 3D Glowing Tropical Crystal Lagoon / Island (ضرب ۳)
        return (
          <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-12 sm:h-12 drop-shadow-[0_4px_12px_rgba(6,182,212,0.7)]" fill="none">
            <defs>
              <linearGradient id="ocean-globe" x1="12" y1="12" x2="52" y2="52" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#67e8f9" />
                <stop offset="45%" stopColor="#06b6d4" />
                <stop offset="100%" stopColor="#0e7490" />
              </linearGradient>
              <linearGradient id="sand-dune" x1="20" y1="36" x2="48" y2="48" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#fef08a" />
                <stop offset="100%" stopColor="#d97706" />
              </linearGradient>
            </defs>
            <circle cx="32" cy="32" r="22" fill="url(#ocean-globe)" stroke="#cffafe" strokeWidth="1.5" />
            {/* Wave ripples */}
            <ellipse cx="32" cy="42" rx="16" ry="6" fill="url(#sand-dune)" />
            {/* Palm trunk */}
            <path d="M28 42 Q32 30 36 24" stroke="#78350f" strokeWidth="2.5" strokeLinecap="round" />
            {/* Palm fronds */}
            <path d="M36 24 Q30 18 24 22" stroke="#22c55e" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M36 24 Q42 17 46 22" stroke="#16a34a" strokeWidth="2.5" strokeLinecap="round" />
            <path d="M36 24 Q36 15 38 14" stroke="#4ade80" strokeWidth="2.5" strokeLinecap="round" />
            {/* Sun glint on ocean glass */}
            <ellipse cx="26" cy="22" rx="5" ry="3" fill="#ffffff" opacity="0.6" transform="rotate(-30 26 22)" />
            <circle cx="44" cy="40" r="1.5" fill="#ffffff" />
          </svg>
        );

      case 4:
        // 3D Glowing Enchanted Emerald Forest Tree (ضرب ۴)
        return (
          <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-12 sm:h-12 drop-shadow-[0_4px_12px_rgba(34,197,94,0.7)]" fill="none">
            <defs>
              <linearGradient id="tree-tier-1" x1="32" y1="10" x2="32" y2="26" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#86efac" />
                <stop offset="100%" stopColor="#15803d" />
              </linearGradient>
              <linearGradient id="tree-tier-2" x1="32" y1="20" x2="32" y2="38" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#4ade80" />
                <stop offset="100%" stopColor="#166534" />
              </linearGradient>
              <linearGradient id="tree-tier-3" x1="32" y1="30" x2="32" y2="48" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#22c55e" />
                <stop offset="100%" stopColor="#14532d" />
              </linearGradient>
            </defs>
            {/* Golden Star on tree top */}
            <polygon points="32,8 33.5,12 37,12 34,14.5 35,18 32,16 29,18 30,14.5 27,12 30.5,12" fill="#facc15" stroke="#fff" strokeWidth="0.8" />
            {/* Tier 1 */}
            <polygon points="32,13 41,25 23,25" fill="url(#tree-tier-1)" stroke="#dcfce7" strokeWidth="1" />
            {/* Tier 2 */}
            <polygon points="32,22 46,36 18,36" fill="url(#tree-tier-2)" stroke="#bbf7d0" strokeWidth="1" />
            {/* Tier 3 */}
            <polygon points="32,32 50,48 14,48" fill="url(#tree-tier-3)" stroke="#86efac" strokeWidth="1" />
            {/* Trunk */}
            <rect x="29" y="48" width="6" height="7" rx="1.5" fill="#78350f" stroke="#451a03" strokeWidth="1" />
            {/* Floating magical orbs */}
            <circle cx="28" cy="23" r="2" fill="#fef08a" />
            <circle cx="36" cy="33" r="2.2" fill="#fb7185" />
            <circle cx="24" cy="42" r="2" fill="#38bdf8" />
            <circle cx="42" cy="43" r="2" fill="#facc15" />
          </svg>
        );

      case 5:
        // 3D Glowing Golden Star Medallion (ضرب ۵)
        return (
          <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-12 sm:h-12 drop-shadow-[0_4px_12px_rgba(245,158,11,0.85)]" fill="none">
            <defs>
              <linearGradient id="star-medal-outer" x1="12" y1="12" x2="52" y2="52" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#fef08a" />
                <stop offset="30%" stopColor="#f59e0b" />
                <stop offset="80%" stopColor="#b45309" />
                <stop offset="100%" stopColor="#78350f" />
              </linearGradient>
              <linearGradient id="star-glyph" x1="32" y1="16" x2="32" y2="48" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="40%" stopColor="#fef08a" />
                <stop offset="100%" stopColor="#eab308" />
              </linearGradient>
            </defs>
            {/* Outer golden gear rim */}
            <circle cx="32" cy="32" r="23" fill="url(#star-medal-outer)" stroke="#fef08a" strokeWidth="1.5" />
            <circle cx="32" cy="32" r="19" fill="#92400e" stroke="#fde047" strokeWidth="1.2" />
            {/* 3D Star in center */}
            <polygon
              points="32,17 36,26 46,27 38,34 41,44 32,38 23,44 26,34 18,27 28,26"
              fill="url(#star-glyph)"
              stroke="#fff"
              strokeWidth="1.2"
            />
            {/* Specular highlight glint */}
            <polygon points="44,14 45,17 48,18 45,19 44,22 43,19 40,18 43,17" fill="#ffffff" />
            <circle cx="25" cy="22" r="1.5" fill="#ffffff" />
          </svg>
        );

      case 6:
        // 3D Glowing Cosmic Violet Saturn / Galaxy (ضرب ۶)
        return (
          <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-12 sm:h-12 drop-shadow-[0_4px_12px_rgba(168,85,247,0.8)]" fill="none">
            <defs>
              <radialGradient id="saturn-body" cx="28" cy="28" r="18" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#e9d5ff" />
                <stop offset="35%" stopColor="#a855f7" />
                <stop offset="75%" stopColor="#6b21a8" />
                <stop offset="100%" stopColor="#3b0764" />
              </radialGradient>
              <linearGradient id="saturn-ring" x1="8" y1="24" x2="56" y2="40" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#22d3ee" />
                <stop offset="50%" stopColor="#e879f9" />
                <stop offset="100%" stopColor="#38bdf8" />
              </linearGradient>
            </defs>
            {/* Ring back half */}
            <ellipse cx="32" cy="33" rx="26" ry="9" fill="none" stroke="url(#saturn-ring)" strokeWidth="4" transform="rotate(-18 32 33)" strokeDasharray="50 50" strokeDashoffset="45" opacity="0.6" />
            {/* Planet Body */}
            <circle cx="32" cy="32" r="16" fill="url(#saturn-body)" stroke="#f3e8ff" strokeWidth="1.2" />
            {/* Cloud bands on planet */}
            <path d="M18 30 Q32 36 46 30" stroke="#d8b4fe" strokeWidth="1.5" fill="none" opacity="0.6" />
            <path d="M19 35 Q32 41 45 35" stroke="#7e22ce" strokeWidth="1.5" fill="none" opacity="0.8" />
            {/* Ring front half */}
            <ellipse cx="32" cy="33" rx="26" ry="9" fill="none" stroke="url(#saturn-ring)" strokeWidth="4.5" transform="rotate(-18 32 33)" strokeDasharray="50 50" strokeDashoffset="0" />
            {/* Glowing stars */}
            <circle cx="12" cy="18" r="1.5" fill="#fef08a" />
            <polygon points="50,14 51,16 53,17 51,18 50,20 49,18 47,17 49,16" fill="#ffffff" />
          </svg>
        );

      case 7:
        // 3D Glowing Radiant Rainbow Arch (ضرب ۷)
        return (
          <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-12 sm:h-12 drop-shadow-[0_4px_12px_rgba(244,63,94,0.7)]" fill="none">
            {/* Ambient aura */}
            <circle cx="32" cy="34" r="22" fill="#ec4899" opacity="0.2" filter="blur(3px)" />
            {/* Rainbow arches */}
            <path d="M12 44 A 20 20 0 0 1 52 44" stroke="#ef4444" strokeWidth="3" strokeLinecap="round" />
            <path d="M15 44 A 17 17 0 0 1 49 44" stroke="#f97316" strokeWidth="3" strokeLinecap="round" />
            <path d="M18 44 A 14 14 0 0 1 46 44" stroke="#facc15" strokeWidth="3" strokeLinecap="round" />
            <path d="M21 44 A 11 11 0 0 1 43 44" stroke="#22c55e" strokeWidth="3" strokeLinecap="round" />
            <path d="M24 44 A 8 8 0 0 1 40 44" stroke="#3b82f6" strokeWidth="3" strokeLinecap="round" />
            <path d="M27 44 A 5 5 0 0 1 37 44" stroke="#a855f7" strokeWidth="2.5" strokeLinecap="round" />
            {/* Puffy Glowing Clouds at bottom */}
            <g fill="#ffffff" stroke="#e0e7ff" strokeWidth="1">
              <circle cx="15" cy="46" r="5" />
              <circle cx="20" cy="45" r="6" />
              <circle cx="25" cy="47" r="4.5" />
              <circle cx="39" cy="47" r="4.5" />
              <circle cx="44" cy="45" r="6" />
              <circle cx="49" cy="46" r="5" />
            </g>
            {/* Rainbow sparkle star */}
            <polygon points="32,12 33,14 36,15 33,16 32,19 31,16 28,15 31,14" fill="#ffffff" />
          </svg>
        );

      case 8:
        // 3D Glowing Ocean Shell with Luminous Pearl (ضرب ۸)
        return (
          <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-12 sm:h-12 drop-shadow-[0_4px_12px_rgba(59,130,246,0.8)]" fill="none">
            <defs>
              <linearGradient id="shell-back" x1="32" y1="12" x2="32" y2="48" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#60a5fa" />
                <stop offset="50%" stopColor="#2563eb" />
                <stop offset="100%" stopColor="#1e3a8a" />
              </linearGradient>
              <radialGradient id="pearl-light" cx="29" cy="33" r="10" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="35%" stopColor="#e0f2fe" />
                <stop offset="70%" stopColor="#93c5fd" />
                <stop offset="100%" stopColor="#3b82f6" />
              </radialGradient>
            </defs>
            {/* Shell Fan Back */}
            <path
              d="M16 44 C12 28 22 14 32 14 C42 14 52 28 48 44 Z"
              fill="url(#shell-back)"
              stroke="#bfdbfe"
              strokeWidth="1.5"
            />
            {/* Shell flutes */}
            <path d="M32 14 L32 44" stroke="#93c5fd" strokeWidth="1.2" opacity="0.6" />
            <path d="M26 17 L30 44" stroke="#93c5fd" strokeWidth="1.2" opacity="0.6" />
            <path d="M38 17 L34 44" stroke="#93c5fd" strokeWidth="1.2" opacity="0.6" />
            {/* Shell Base Lip */}
            <ellipse cx="32" cy="46" rx="18" ry="6" fill="#1e40af" stroke="#93c5fd" strokeWidth="1.2" />
            {/* Large Glowing Pearl */}
            <circle cx="32" cy="36" r="10" fill="url(#pearl-light)" stroke="#ffffff" strokeWidth="1.5" />
            {/* Specular highlight */}
            <circle cx="29" cy="33" r="3.5" fill="#ffffff" />
            <circle cx="35" cy="38" r="1.5" fill="#ffffff" opacity="0.7" />
          </svg>
        );

      case 9:
        // 3D Glowing Floating Cloud Castle (ضرب ۹)
        return (
          <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-12 sm:h-12 drop-shadow-[0_4px_12px_rgba(99,102,241,0.8)]" fill="none">
            <defs>
              <linearGradient id="castle-wall" x1="20" y1="18" x2="44" y2="44" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#c7d2fe" />
                <stop offset="50%" stopColor="#818cf8" />
                <stop offset="100%" stopColor="#4338ca" />
              </linearGradient>
            </defs>
            {/* Castle Center Spire */}
            <rect x="27" y="22" width="10" height="20" fill="url(#castle-wall)" stroke="#e0e7ff" strokeWidth="1" />
            <polygon points="26,22 32,10 38,22" fill="#f43f5e" stroke="#fff" strokeWidth="1" />
            {/* Left Tower */}
            <rect x="18" y="27" width="8" height="15" fill="url(#castle-wall)" stroke="#e0e7ff" strokeWidth="1" />
            <polygon points="17,27 22,17 27,27" fill="#f59e0b" stroke="#fff" strokeWidth="1" />
            {/* Right Tower */}
            <rect x="38" y="27" width="8" height="15" fill="url(#castle-wall)" stroke="#e0e7ff" strokeWidth="1" />
            <polygon points="37,27 42,17 47,27" fill="#f59e0b" stroke="#fff" strokeWidth="1" />
            {/* Golden Flag */}
            <path d="M32 10 L32 6 L36 8 L32 10" fill="#facc15" />
            {/* Puffy Glowing Base Cloud */}
            <g fill="#ffffff" stroke="#c7d2fe" strokeWidth="1.2">
              <circle cx="16" cy="46" r="7" />
              <circle cx="25" cy="44" r="9" />
              <circle cx="36" cy="43" r="10" />
              <circle cx="48" cy="46" r="7" />
            </g>
            {/* Golden sparkles */}
            <circle cx="14" cy="20" r="1.5" fill="#fde047" />
            <circle cx="50" cy="20" r="1.5" fill="#fde047" />
          </svg>
        );

      case 10:
        // 3D Glowing Solar Corona Sun (ضرب ۱۰)
        return (
          <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-12 sm:h-12 drop-shadow-[0_4px_14px_rgba(249,115,22,0.85)]" fill="none">
            <defs>
              <radialGradient id="sun-core" cx="30" cy="30" r="16" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="25%" stopColor="#fef08a" />
                <stop offset="60%" stopColor="#f59e0b" />
                <stop offset="100%" stopColor="#ea580c" />
              </radialGradient>
              <linearGradient id="sun-ray" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#fde047" />
                <stop offset="100%" stopColor="#ea580c" />
              </linearGradient>
            </defs>
            {/* 12 Solar Rays */}
            {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((angle, idx) => (
              <polygon
                key={idx}
                points="32,7 34,16 30,16"
                fill="url(#sun-ray)"
                stroke="#fff"
                strokeWidth="0.8"
                transform={`rotate(${angle} 32 32)`}
              />
            ))}
            {/* Solar Orb */}
            <circle cx="32" cy="32" r="16" fill="url(#sun-core)" stroke="#fef08a" strokeWidth="2" />
            {/* Smiling happy eyes & cheerful smile for students! */}
            <circle cx="27" cy="30" r="2" fill="#7c2d12" />
            <circle cx="37" cy="30" r="2" fill="#7c2d12" />
            <path d="M27 35 Q32 40 37 35" stroke="#7c2d12" strokeWidth="2" strokeLinecap="round" fill="none" />
            {/* Pink cheeks */}
            <circle cx="23" cy="33" r="2" fill="#f43f5e" opacity="0.6" />
            <circle cx="41" cy="33" r="2" fill="#f43f5e" opacity="0.6" />
            {/* Specular gloss */}
            <ellipse cx="26" cy="24" rx="4" ry="2" fill="#ffffff" opacity="0.75" transform="rotate(-30 26 24)" />
          </svg>
        );

      case 11:
      default:
        // 3D Glowing Grand Champions Golden Trophy (جام قهرمانان)
        return (
          <svg viewBox="0 0 64 64" className="w-10 h-10 sm:w-12 sm:h-12 drop-shadow-[0_4px_14px_rgba(234,179,8,0.9)]" fill="none">
            <defs>
              <linearGradient id="cup-gold" x1="16" y1="12" x2="48" y2="40" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="25%" stopColor="#fef08a" />
                <stop offset="60%" stopColor="#eab308" />
                <stop offset="85%" stopColor="#ca8a04" />
                <stop offset="100%" stopColor="#854d0e" />
              </linearGradient>
              <radialGradient id="ruby-gem" cx="32" cy="26" r="5" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#fecdd3" />
                <stop offset="40%" stopColor="#f43f5e" />
                <stop offset="100%" stopColor="#881337" />
              </radialGradient>
            </defs>
            {/* Left Wing Handle */}
            <path
              d="M20 18 C10 18 10 32 21 34"
              stroke="url(#cup-gold)"
              strokeWidth="3.5"
              strokeLinecap="round"
              fill="none"
            />
            {/* Right Wing Handle */}
            <path
              d="M44 18 C54 18 54 32 43 34"
              stroke="url(#cup-gold)"
              strokeWidth="3.5"
              strokeLinecap="round"
              fill="none"
            />
            {/* Trophy Chalice Cup Body */}
            <path
              d="M20 14 H44 C44 28 39 38 32 38 C25 38 20 28 20 14 Z"
              fill="url(#cup-gold)"
              stroke="#fff"
              strokeWidth="1.5"
            />
            {/* Cup Rim Highlight */}
            <ellipse cx="32" cy="14" rx="12" ry="3" fill="#fef08a" stroke="#ffffff" strokeWidth="1" />
            {/* Red Ruby Gem inside Trophy */}
            <polygon points="32,22 36,26 32,30 28,26" fill="url(#ruby-gem)" stroke="#fff" strokeWidth="0.8" />
            {/* Stem */}
            <rect x="30" y="38" width="4" height="8" fill="url(#cup-gold)" />
            {/* Base Pedestal */}
            <path d="M22 46 H42 L44 54 H20 Z" fill="#854d0e" stroke="#fef08a" strokeWidth="1.2" />
            <rect x="23" y="47" width="18" height="5" fill="url(#cup-gold)" />
            {/* Sparkles */}
            <polygon points="46,12 47,14 49,15 47,16 46,18 45,16 43,15 45,14" fill="#ffffff" />
            <circle cx="18" cy="24" r="1.5" fill="#ffffff" />
          </svg>
        );
    }
  };

  const getStageColorBadge = () => {
    switch (level) {
      case 1:
        return 'bg-pink-500/90 text-pink-100 border-pink-300';
      case 2:
        return 'bg-emerald-500/90 text-emerald-100 border-emerald-300';
      case 3:
        return 'bg-cyan-500/90 text-cyan-100 border-cyan-300';
      case 4:
        return 'bg-green-600/90 text-green-100 border-green-300';
      case 5:
        return 'bg-amber-500/90 text-amber-100 border-yellow-300';
      case 6:
        return 'bg-purple-600/90 text-purple-100 border-purple-300';
      case 7:
        return 'bg-fuchsia-600/90 text-fuchsia-100 border-fuchsia-300';
      case 8:
        return 'bg-blue-600/90 text-blue-100 border-blue-300';
      case 9:
        return 'bg-indigo-600/90 text-indigo-100 border-indigo-300';
      case 10:
        return 'bg-orange-500/90 text-orange-100 border-amber-300';
      case 11:
      default:
        return 'bg-yellow-400 text-amber-950 border-white font-black';
    }
  };

  return (
    <div className={`flex flex-col items-center justify-center p-1 text-center select-none ${className}`}>
      <div className="relative flex items-center justify-center transition-transform hover:scale-110 duration-200">
        {renderIcon()}
      </div>

      {showBadge && (
        <span
          className={`mt-1 text-[9px] sm:text-[10px] font-black px-1.5 py-0.2 rounded-full border shadow-xs tracking-tight ${getStageColorBadge()}`}
        >
          {level === 11 ? 'جام نهایی' : `ضرب ${toPersianDigits(level)}`}
        </span>
      )}
    </div>
  );
};
