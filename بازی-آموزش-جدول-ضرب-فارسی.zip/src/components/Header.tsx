import React, { useState } from 'react';
import { Volume2, VolumeX, RotateCcw, Award, BookOpen, Grid, X } from 'lucide-react';
import { soundManager } from '../utils/soundEffects';
import { toPersianDigits } from '../utils/persianNumbers';

interface HeaderProps {
  currentLevel: number;
  totalStars: number;
  isMapActive: boolean;
  onOpenLevelMap: () => void;
  onCloseLevelMap: () => void;
  onResetProgress: () => void;
  soundMuted: boolean;
  onToggleSound: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  totalStars,
  isMapActive,
  onOpenLevelMap,
  onResetProgress,
  soundMuted,
  onToggleSound,
}) => {
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const [showGameRules, setShowGameRules] = useState(false);

  return (
    <header className="w-full bg-gradient-to-b from-[#200c02] via-[#2f1304] to-[#3a1805] border-b-2 border-amber-800/80 sticky top-0 z-30 shadow-md">
      <div className="max-w-xl mx-auto px-2.5 py-1.5 sm:px-3 sm:py-2 flex items-center justify-between gap-1.5 sm:gap-2">
        {/* Left Side: Store/Rules & Stage Navigation */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          <button
            onClick={() => {
              soundManager.playClick();
              setShowGameRules(true);
            }}
            className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-b from-[#874015] to-[#512307] border-2 border-[#b86127] text-amber-200 hover:text-white flex items-center justify-center shadow-[0_2px_0_#1e0c03] active:translate-y-0.5 transition-all cursor-pointer"
            title="راهنمای بازی و قوانین"
          >
            <BookOpen className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300 drop-shadow-xs" />
          </button>

          {!isMapActive && (
            <button
              onClick={() => {
                soundManager.playClick();
                onOpenLevelMap();
              }}
              className="h-8 sm:h-10 px-2 sm:px-2.5 rounded-xl bg-gradient-to-b from-[#874015] to-[#512307] border-2 border-[#b86127] text-amber-100 font-bold text-[11px] sm:text-xs flex items-center gap-1 shadow-[0_2px_0_#1e0c03] active:translate-y-0.5 transition-all cursor-pointer"
              title="بازگشت به تابلوی مراحل"
            >
              <Grid className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-300" />
              <span>مراحل</span>
            </button>
          )}
        </div>

        {/* Center: Producer Credit Tag in Gold (Clean & Compact on mobile) */}
        <div className="flex items-center gap-1 sm:gap-1.5 bg-black/45 border border-amber-500/50 rounded-xl px-2 sm:px-2.5 py-1 shadow-xs truncate">
          <Award className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400 shrink-0" />
          <div className="text-[10px] sm:text-[11px] font-bold text-amber-200 whitespace-nowrap">
            تهیه کننده: <span className="text-yellow-300 font-extrabold">سید یونس اعجازی</span>
          </div>
        </div>

        {/* Right Side: 3D Golden Coins Capsule & Controls */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {/* Golden Coin Counter Capsule */}
          <div className="flex items-center gap-1 bg-gradient-to-b from-amber-400 via-amber-500 to-yellow-600 text-amber-950 font-black px-2 py-0.5 sm:px-2.5 sm:py-1 rounded-xl sm:rounded-2xl border border-amber-200 shadow-[0_2px_0_#78350f]">
            {/* 3D Luminous Golden Coin SVG */}
            <svg viewBox="0 0 24 24" className="w-4 h-4 sm:w-5 sm:h-5 drop-shadow-[0_1px_2px_rgba(0,0,0,0.5)]" fill="none">
              <circle cx="12" cy="12" r="10" fill="url(#coin-gold-grad)" stroke="#fffbeb" strokeWidth="1.2" />
              <circle cx="12" cy="12" r="7.5" fill="#ca8a04" stroke="#fef08a" strokeWidth="0.8" />
              <polygon points="12,6.5 13.6,9.8 17.2,10.3 14.6,12.8 15.2,16.4 12,14.7 8.8,16.4 9.4,12.8 6.8,10.3 10.4,9.8" fill="#ffffff" />
              <defs>
                <linearGradient id="coin-gold-grad" x1="4" y1="4" x2="20" y2="20" gradientUnits="userSpaceOnUse">
                  <stop offset="0%" stopColor="#fef08a" />
                  <stop offset="40%" stopColor="#eab308" />
                  <stop offset="100%" stopColor="#a16207" />
                </linearGradient>
              </defs>
            </svg>

            <span className="tabular-nums text-xs sm:text-sm font-black tracking-tight text-amber-950">
              {toPersianDigits(totalStars * 15 + 10)}
            </span>
          </div>

          {/* Sound Mute/Unmute */}
          <button
            onClick={onToggleSound}
            className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl border flex items-center justify-center transition-all cursor-pointer active:translate-y-0.5 shadow-[0_2px_0_#1e0c03] ${
              soundMuted
                ? 'bg-rose-950 border-rose-600 text-rose-300'
                : 'bg-emerald-950 border-emerald-500 text-emerald-300'
            }`}
            title={soundMuted ? 'روشن کردن صدا' : 'قطع صدا'}
          >
            {soundMuted ? <VolumeX className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Volume2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
          </button>

          {/* Reset button */}
          <button
            onClick={() => {
              soundManager.playClick();
              setShowConfirmReset(true);
            }}
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-[#451c07] border border-[#7c3913] text-amber-300/80 hover:text-amber-100 flex items-center justify-center transition-all cursor-pointer active:translate-y-0.5 shadow-[0_2px_0_#1e0c03]"
            title="شروع مجدد از مرحله اول"
          >
            <RotateCcw className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </button>
        </div>
      </div>

      {/* Rules Modal */}
      {showGameRules && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4">
          <div className="wood-board rounded-3xl p-5 sm:p-6 max-w-sm w-full shadow-2xl text-right relative border-3 border-amber-500">
            <button
              onClick={() => setShowGameRules(false)}
              className="absolute top-3 left-3 w-8 h-8 rounded-full bg-amber-900/80 text-amber-200 hover:text-white flex items-center justify-center border border-amber-700 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2.5 mb-3">
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-b from-amber-400 to-yellow-600 text-amber-950 flex items-center justify-center font-black shadow-md border border-yellow-200">
                <BookOpen className="w-6 h-6 text-amber-950" />
              </div>
              <div>
                <h3 className="text-base font-black text-white">قوانین و راهنمای بازی</h3>
                <p className="text-[11px] text-amber-300 font-bold">تهیه کننده: سید یونس اعجازی</p>
              </div>
            </div>

            <div className="space-y-2.5 text-xs text-amber-100 leading-relaxed bg-black/45 p-3.5 rounded-2xl border border-amber-800">
              <p>• بازی شامل ۱۱ مرحله است که از مرحله ۱ (ضرب عدد ۱) تا مرحله ۱۰ (ضرب عدد ۱۰) ادامه می‌یابد.</p>
              <p>• در هر مرحله، ضرب عدد آن مرحله در اول نوشته می‌شود (از چپ به راست).</p>
              <p>• مرحله ۱۱ قله طلایی قهرمانان است که سوالات تصادفی از کل جدول ضرب دارد.</p>
              <p>• با فتح هر مرحله، قفل طلایی باز شده و نماد سه‌بعدی و نورانی آن مرحله نمایان می‌شود و تیک سبز موفقیت ثبت می‌گردد.</p>
              <p className="text-yellow-300 font-bold">• شرط باز شدن مرحله بعد: باید تمام ۱۰ سوال را ۱۰۰٪ درست و بدون حتی ۱ خطا حل کنید.</p>
            </div>

            <button
              onClick={() => setShowGameRules(false)}
              className="mt-4 w-full py-2.5 bg-gradient-to-r from-amber-400 to-yellow-500 hover:brightness-110 text-amber-950 font-black text-xs rounded-xl shadow-[0_3px_0_#b45309] cursor-pointer"
            >
              متوجه شدم، بزن بریم!
            </button>
          </div>
        </div>
      )}

      {/* Reset Confirmation Modal */}
      {showConfirmReset && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4">
          <div className="wood-board rounded-3xl p-5 max-w-xs w-full shadow-2xl text-center space-y-3 border-2 border-rose-800">
            <div className="w-12 h-12 bg-rose-900/60 text-rose-400 rounded-2xl flex items-center justify-center mx-auto border border-rose-700">
              <RotateCcw className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-white">آیا می‌خواهید از اول شروع کنید؟</h3>
            <p className="text-xs text-amber-200/80 leading-relaxed">
              تمام مراحل و ستاره‌ها بازنشانی می‌شوند و بازی از مرحله ۱ شروع خواهد شد.
            </p>
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => {
                  onResetProgress();
                  setShowConfirmReset(false);
                }}
                className="flex-1 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-[0_3px_0_#9f1239] cursor-pointer"
              >
                بله، شروع مجدد
              </button>
              <button
                onClick={() => setShowConfirmReset(false)}
                className="flex-1 py-2 bg-amber-950 hover:bg-amber-900 text-amber-200 text-xs font-bold rounded-xl border border-amber-800 cursor-pointer"
              >
                انصراف
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
