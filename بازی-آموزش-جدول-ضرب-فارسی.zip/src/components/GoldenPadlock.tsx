import React from 'react';

interface GoldenPadlockProps {
  className?: string;
}

export const GoldenPadlock: React.FC<GoldenPadlockProps> = ({ className = 'w-12 h-14' }) => {
  return (
    <div className={`relative flex items-center justify-center gold-padlock select-none ${className}`}>
      <svg
        viewBox="0 0 64 74"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-[0_4px_6px_rgba(0,0,0,0.7)]"
      >
        <defs>
          {/* Shackle metallic gradient */}
          <linearGradient id="shackle-grad" x1="16" y1="6" x2="48" y2="30" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="35%" stopColor="#d97706" />
            <stop offset="70%" stopColor="#b45309" />
            <stop offset="100%" stopColor="#78350f" />
          </linearGradient>

          {/* Shackle inner cutout gradient */}
          <linearGradient id="shackle-inner-grad" x1="24" y1="12" x2="40" y2="28" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#1f0a02" />
            <stop offset="100%" stopColor="#0a0301" />
          </linearGradient>

          {/* Body gold gradient */}
          <linearGradient id="body-gold-grad" x1="10" y1="26" x2="54" y2="70" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#fde047" />
            <stop offset="15%" stopColor="#f59e0b" />
            <stop offset="50%" stopColor="#d97706" />
            <stop offset="85%" stopColor="#b45309" />
            <stop offset="100%" stopColor="#78350f" />
          </linearGradient>

          {/* Body inner plate gradient */}
          <linearGradient id="body-inner-grad" x1="16" y1="32" x2="48" y2="64" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#d97706" />
            <stop offset="40%" stopColor="#b45309" />
            <stop offset="100%" stopColor="#78350f" />
          </linearGradient>

          {/* Rivet gradient */}
          <linearGradient id="rivet-grad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="100%" stopColor="#92400e" />
          </linearGradient>
        </defs>

        {/* Lock Shackle (Arched loop) */}
        <path
          d="M20 32 V 18 C 20 11.3726 25.3726 6 32 6 C 38.6274 6 44 11.3726 44 18 V 32"
          stroke="url(#shackle-grad)"
          strokeWidth="7"
          strokeLinecap="round"
        />
        {/* Shackle inner shadow */}
        <path
          d="M22 30 V 18 C 22 12.4772 26.4772 8 32 8 C 37.5228 8 42 12.4772 42 18 V 30"
          stroke="rgba(0,0,0,0.3)"
          strokeWidth="2"
          strokeLinecap="round"
        />

        {/* Main Golden Body with beveled corners */}
        <rect
          x="10"
          y="28"
          width="44"
          height="40"
          rx="8"
          fill="url(#body-gold-grad)"
          stroke="#fef08a"
          strokeWidth="1.5"
        />

        {/* Inner carved plate on lock body */}
        <rect
          x="15"
          y="33"
          width="34"
          height="30"
          rx="5"
          fill="url(#body-inner-grad)"
          stroke="#92400e"
          strokeWidth="1"
        />

        {/* Diagonal Gloss / Specular Light Reflection across body */}
        <path
          d="M14 30 L40 30 L16 66 L12 66 Z"
          fill="#ffffff"
          opacity="0.18"
        />

        {/* 4 Corner Rivets / Screws */}
        <circle cx="18" cy="36" r="1.5" fill="url(#rivet-grad)" />
        <circle cx="46" cy="36" r="1.5" fill="url(#rivet-grad)" />
        <circle cx="18" cy="60" r="1.5" fill="url(#rivet-grad)" />
        <circle cx="46" cy="60" r="1.5" fill="url(#rivet-grad)" />

        {/* Keyhole (Embossed black circular top with tapered slit) */}
        <circle cx="32" cy="46" r="4" fill="#180702" />
        <path d="M30 46 L29.5 56 H34.5 L34 46 Z" fill="#180702" />
        {/* Keyhole golden inner rim highlight */}
        <path
          d="M32 42.5 C 34 42.5 35.5 44 35.5 46 C 35.5 47 35 48 34.5 49 L34.5 55.5 C 34.5 56 34 56.5 33.5 56.5 H30.5 C 30 56.5 29.5 56 29.5 55.5 L29.5 49 C 29 48 28.5 47 28.5 46 C 28.5 44 30 42.5 32 42.5 Z"
          stroke="#fde047"
          strokeWidth="0.8"
          fill="none"
          opacity="0.9"
        />

        {/* Golden Glint Star */}
        <polygon points="46,30 47,32 49,33 47,34 46,36 45,34 43,33 45,32" fill="#ffffff" opacity="0.85" />
      </svg>
    </div>
  );
};
