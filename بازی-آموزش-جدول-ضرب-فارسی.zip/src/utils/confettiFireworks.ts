import confetti from 'canvas-confetti';

/**
 * Quick, stylish, and elegant single celebratory sparkle burst for victory modal
 */
export function launchCelebrationFireworks(): void {
  try {
    confetti({
      particleCount: 50,
      spread: 70,
      startVelocity: 30,
      ticks: 100,
      gravity: 0.9,
      origin: { x: 0.5, y: 0.4 },
      colors: ['#facc15', '#f59e0b', '#34d399', '#38bdf8', '#c084fc', '#ffffff'],
      shapes: ['star', 'circle'],
      scalar: 1,
      zIndex: 9999,
      disableForReducedMotion: true,
    });
  } catch (e) {
    // Ignore canvas errors on low-memory mobile webviews
  }
}

export const triggerVictoryConfetti = launchCelebrationFireworks;

/**
 * Question-level visual sparkle:
 * Kept lightweight without full-screen canvas injection to prevent GPU layer flash on mobile browsers
 */
export function triggerCorrectSparkle(_originX = 0.5, _originY = 0.5): void {
  // Purposefully no canvas creation here to prevent white screen flickers on mobile/Xiaomi browsers.
  // Visual feedback is cleanly handled via high-contrast CSS 3D button animations.
}
