// Multiplication Game Logic, Story Realms, and Question Generator

export interface Question {
  id: string;
  num1: number;
  num2: number;
  answer: number;
  options: number[];
  userAnswer?: number;
  isCorrect?: boolean;
}

export interface StoryRealm {
  level: number;
  name: string;
  badge: string;
  icon3D: string; // thematic visual emoji / symbol
  color: string;
  bgGradient: string;
  borderColor: string;
  shadowColor: string;
  themeLabel: string;
  story: string;
  mission: string;
  landmark: string;
}

export const STORY_REALMS: StoryRealm[] = [
  {
    level: 1,
    name: 'شهر شکوفه‌ها',
    badge: 'دروازه آغازین',
    icon3D: '🌸',
    color: 'from-pink-500 to-rose-600',
    bgGradient: 'from-pink-50 via-rose-50 to-pink-100/60',
    borderColor: 'border-pink-300',
    shadowColor: '#e11d48',
    themeLabel: 'ضرب عدد ۱',
    story: 'سفر بزرگ شما از دروازه سرسبز شهر شکوفه‌ها آغاز می‌شود. ساکنان مهربان این شهر پایه‌های اولیه ریاضی را به شما می‌آموزند.',
    mission: 'پاسخ به ۱۰ ضرب ساده عدد ۱ برای باز شدن پل عبور به دره زمردین',
    landmark: 'پل عطرآگین شکوفه‌ها',
  },
  {
    level: 2,
    name: 'دره زمردین',
    badge: 'قلمرو جفت‌ها',
    icon3D: '💎',
    color: 'from-emerald-500 to-teal-600',
    bgGradient: 'from-emerald-50 via-teal-50 to-emerald-100/60',
    borderColor: 'border-emerald-300',
    shadowColor: '#059669',
    themeLabel: 'ضرب عدد ۲',
    story: 'در این دره همه‌چیز جفت و متقارن است؛ کریستال‌های زمرد دو به دو می‌درخشند و با جدول ۲ به استقبال شما می‌آیند.',
    mission: 'شمارش دو به دو و حل بی‌نقص ۱۰ معمای دره زمردین',
    landmark: 'غار کریستال‌های سبز',
  },
  {
    level: 3,
    name: 'جزیره بلورین',
    badge: 'قلمرو مثلث‌ها',
    icon3D: '🏝️',
    color: 'from-cyan-500 to-blue-600',
    bgGradient: 'from-cyan-50 via-blue-50 to-cyan-100/60',
    borderColor: 'border-cyan-300',
    shadowColor: '#0284c7',
    themeLabel: 'ضرب عدد ۳',
    story: 'جزیره‌ای درخشان در دل اقیانوس که معابد باستانی آن به شکل مثلث‌های نورانی ساخته شده‌اند.',
    mission: 'کشف رمز و راز سه‌گانه‌ها و گشودن قفل کشتی به سمت جنگل جادویی',
    landmark: 'برج دیده‌بانی اقیانوس',
  },
  {
    level: 4,
    name: 'جنگل چهارفصل',
    badge: 'سرزمین گنجینه‌ها',
    icon3D: '🌲',
    color: 'from-green-600 to-emerald-700',
    bgGradient: 'from-green-50 via-emerald-50 to-green-100/60',
    borderColor: 'border-green-400',
    shadowColor: '#15803d',
    themeLabel: 'ضرب عدد ۴',
    story: 'درختان کهنسال این جنگل چهار شاخه طلایی دارند که کلید عبور به اعماق نقشه ماجراجویی است.',
    mission: 'حل ۱۰ معمای عدد ۴ در بیشه پر رمز و راز چهارفصل',
    landmark: 'درخت زندگی هزارساله',
  },
  {
    level: 5,
    name: 'دشت سکه‌های طلایی',
    badge: 'پادشاهی زمان',
    icon3D: '⭐',
    color: 'from-amber-400 to-yellow-500',
    bgGradient: 'from-amber-50 via-yellow-50 to-amber-100/60',
    borderColor: 'border-amber-300',
    shadowColor: '#d97706',
    themeLabel: 'ضرب عدد ۵',
    story: 'سرزمین ساعت‌های شنی و سکه‌های درخشان پنج‌تایی. شمارش عدد ۵ در این دشت بسیار لذت‌بخش و پرسرعت است.',
    mission: 'به دست آوردن ۱۰ نشان طلایی با دقت ۱۰۰٪ برای رسیدن به قله کهکشان',
    landmark: 'کاروانسرای پنج‌گانه',
  },
  {
    level: 6,
    name: 'کهکشان بنفش',
    badge: 'کندوی شش‌ضلعی‌ها',
    icon3D: '🪐',
    color: 'from-purple-500 to-indigo-600',
    bgGradient: 'from-purple-50 via-indigo-50 to-purple-100/60',
    borderColor: 'border-purple-300',
    shadowColor: '#7c3aed',
    themeLabel: 'ضرب عدد ۶',
    story: 'در این دنیای فضایی، ستارگان در مدارهای شش‌گوشه می‌چرخند و آزمون‌های هوش را سخت‌تر می‌کنند.',
    mission: 'روشن کردن مدارهای کهکشانی با حل بدون خطای ضرب‌های ۶',
    landmark: 'رصدخانه شش‌ضلعی',
  },
  {
    level: 7,
    name: 'کوهستان رنگین‌کمان',
    badge: 'هفت خوان دانایی',
    icon3D: '🌈',
    color: 'from-rose-500 via-purple-500 to-indigo-600',
    bgGradient: 'from-fuchsia-50 via-purple-50 to-pink-100/60',
    borderColor: 'border-fuchsia-300',
    shadowColor: '#c026d3',
    themeLabel: 'ضرب عدد ۷',
    story: 'هفت قله رنگین‌کمان نیازمند شجاعت، تمرکز و دقت بالاست. هر گام شما رنگی تازه به آسمان می‌بخشد.',
    mission: 'فتح قله‌های هفتگانه با تسلط کامل بر ضرب عدد ۷',
    landmark: 'پل معلق رنگ‌ها',
  },
  {
    level: 8,
    name: 'اقیانوس مروارید',
    badge: 'اعماق حکمت',
    icon3D: '🌊',
    color: 'from-blue-600 to-teal-700',
    bgGradient: 'from-blue-50 via-teal-50 to-sky-100/60',
    borderColor: 'border-blue-300',
    shadowColor: '#1d4ed8',
    themeLabel: 'ضرب عدد ۸',
    story: 'هشت‌پا‌های دانا در کف اقیانوس نگهبان صدف‌های مروارید هستند. با هر پاسخ درست، مرواریدی درخشان هدیه می‌گیرید.',
    mission: 'غواصی در ۱۰ معمای عمیق ضرب عدد ۸ بدون حتی یک لغزش',
    landmark: 'قصر مرجانی اقیانوس',
  },
  {
    level: 9,
    name: 'قلعه ابرها',
    badge: 'آشیانه سیمرغ',
    icon3D: '☁️',
    color: 'from-indigo-500 to-slate-700',
    bgGradient: 'from-indigo-50 via-slate-50 to-indigo-100/60',
    borderColor: 'border-indigo-300',
    shadowColor: '#4338ca',
    themeLabel: 'ضرب عدد ۹',
    story: 'قلعه‌ای باشکوه معلق بر فراز ابرها که اسرار جدول شگفت‌انگیز عدد ۹ در دیواره‌های آن حک شده است.',
    mission: 'رمزگشایی از ۱۰ راز جادویی ضرب عدد ۹ و رسیدن به پایتخت خورشید',
    landmark: 'برج فلک‌الافلاک ابرها',
  },
  {
    level: 10,
    name: 'پایتخت خورشید',
    badge: 'دروازه بزرگ دهگان‌ها',
    icon3D: '☀️',
    color: 'from-amber-500 to-orange-600',
    bgGradient: 'from-amber-50 via-orange-50 to-yellow-100/60',
    borderColor: 'border-amber-400',
    shadowColor: '#c2410c',
    themeLabel: 'ضرب عدد ۱۰',
    story: 'پایتخت پرنور پادشاهی ریاضیات! ضرب عدد ۱۰ با شکوه تمام دروازه‌های طلایی را به روی شما می‌گشاید.',
    mission: 'پاسخ سریع و دقیق به ۱۰ سوال ضرب ۱۰ و آزادسازی جام قهرمانان',
    landmark: 'کاخ باشکوه خورشید',
  },
  {
    level: 11,
    name: 'قله طلایی قهرمانان',
    badge: 'چالش بزرگ نهایی',
    icon3D: '🏆',
    color: 'from-yellow-400 via-amber-500 to-orange-600',
    bgGradient: 'from-yellow-50 via-amber-100/70 to-orange-100/80',
    borderColor: 'border-amber-400',
    shadowColor: '#b45309',
    themeLabel: 'کل جدول ضرب (سوالات تصادفی)',
    story: 'ایستگاه نهایی ماجراجویی! جایی که تمام قهرمانان ریاضی در آزمونی تصادفی از تمام ۱۰ شهر به رقابت می‌پردازند.',
    mission: 'پاسخ به ۱۰ سوال چهارگزینه‌ای تصادفی از کل جدول ضرب برای دریافت جام ابدی و عنوان «استاد جدول ضرب»',
    landmark: 'تندیس طلایی دانای کل',
  },
];

export function getStoryRealm(levelNumber: number): StoryRealm {
  const found = STORY_REALMS.find((r) => r.level === levelNumber);
  return found || STORY_REALMS[0];
}

/**
 * Generate 3 realistic distractor options around the correct answer (num1 * num2)
 */
export function generateDistractors(num1: number, num2: number, answer: number): number[] {
  const optionsSet = new Set<number>([answer]);
  const candidates: number[] = [];

  // Multiples in the same table (e.g. for 7x6: 7x4=28, 7x5=35, 7x7=49, 7x8=56)
  if (num2 > 1) candidates.push(num1 * (num2 - 1));
  if (num2 > 2) candidates.push(num1 * (num2 - 2));
  candidates.push(num1 * (num2 + 1));
  candidates.push(num1 * (num2 + 2));

  // Multiples in adjacent table
  if (num1 > 1) candidates.push((num1 - 1) * num2);
  candidates.push((num1 + 1) * num2);

  // Common calculation slips
  candidates.push(answer + 2);
  candidates.push(Math.max(1, answer - 2));
  candidates.push(answer + 10);
  if (answer > 10) candidates.push(answer - 10);

  // Shuffle candidates
  const shuffledCandidates = [...candidates].sort(() => Math.random() - 0.5);

  for (const cand of shuffledCandidates) {
    if (cand > 0 && cand !== answer && !optionsSet.has(cand)) {
      optionsSet.add(cand);
      if (optionsSet.size === 4) break;
    }
  }

  // Fallback randoms if not enough unique options
  let offset = 1;
  while (optionsSet.size < 4) {
    const fallback = Math.max(1, answer + (Math.random() < 0.5 ? offset : -offset));
    if (!optionsSet.has(fallback)) {
      optionsSet.add(fallback);
    }
    offset++;
  }

  // Shuffle final 4 options
  return Array.from(optionsSet).sort(() => Math.random() - 0.5);
}

/**
 * Generate 10 questions for a given level
 * Level 1 to 10: Multiplications of that specific number (1..10)
 * Level 11 (Final Champion Stage): 10 random questions from across the entire 1..10 table
 */
export function generateQuestionsForLevel(levelNumber: number): Question[] {
  const questions: Question[] = [];

  if (levelNumber >= 1 && levelNumber <= 10) {
    const multipliers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].sort(() => Math.random() - 0.5);

    multipliers.forEach((num2, idx) => {
      const num1 = levelNumber;
      const answer = num1 * num2;
      const options = generateDistractors(num1, num2, answer);

      questions.push({
        id: `lvl-${levelNumber}-q-${idx + 1}`,
        num1,
        num2,
        answer,
        options,
      });
    });
  } else {
    const usedPairs = new Set<string>();
    while (questions.length < 10) {
      const num1 = Math.floor(Math.random() * 9) + 2; // 2 to 10
      const num2 = Math.floor(Math.random() * 9) + 2; // 2 to 10
      const pairKey = `${num1}x${num2}`;
      if (!usedPairs.has(pairKey)) {
        usedPairs.add(pairKey);
        const answer = num1 * num2;
        const options = generateDistractors(num1, num2, answer);
        questions.push({
          id: `final-q-${questions.length + 1}`,
          num1,
          num2,
          answer,
          options,
        });
      }
    }
  }

  return questions;
}

const STORAGE_KEY = 'persian_multiplication_progress_v3';

export interface SavedProgress {
  unlockedLevels: number; // e.g. 1 to 11
  completedLevels: number[]; // array of completed level numbers
  totalStars: number;
}

export function loadGameProgress(): SavedProgress {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {
    // fallback
  }
  return {
    unlockedLevels: 1, // Only level 1 is unlocked initially
    completedLevels: [],
    totalStars: 0,
  };
}

export function saveGameProgress(progress: SavedProgress): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // ignore
  }
}
