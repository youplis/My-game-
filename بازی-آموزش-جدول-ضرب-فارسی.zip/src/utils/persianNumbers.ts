// Utility functions for Persian digits and number formatting

const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

export function toPersianDigits(n: number | string): string {
  if (n === null || n === undefined) return '';
  return n
    .toString()
    .replace(/[0-9]/g, (w) => persianDigits[parseInt(w, 10)]);
}

export function toEnglishDigits(str: string): string {
  return str.replace(/[۰-۹]/g, (char) => {
    return String(persianDigits.indexOf(char));
  });
}

const persianNumberWords: Record<number, string> = {
  0: 'صفر',
  1: 'یک',
  2: 'دو',
  3: 'سه',
  4: 'چهار',
  5: 'پنج',
  6: 'شش',
  7: 'هفت',
  8: 'هشت',
  9: 'نه',
  10: 'ده',
  11: 'یازده',
  12: 'دوازده',
  13: 'سیزده',
  14: 'چهارده',
  15: 'پانزده',
  16: 'شانزده',
  17: 'هفده',
  18: 'هجده',
  19: 'نوزده',
  20: 'بیست',
  30: 'سی',
  40: 'چهل',
  50: 'پنجاه',
  60: 'شصت',
  70: 'هفتاد',
  80: 'هشتاد',
  90: 'نود',
  100: 'صد',
};

export function numberToPersianWords(num: number): string {
  if (persianNumberWords[num]) {
    return persianNumberWords[num];
  }
  if (num > 20 && num < 100) {
    const tens = Math.floor(num / 10) * 10;
    const ones = num % 10;
    return `${persianNumberWords[tens]} و ${persianNumberWords[ones]}`;
  }
  return toPersianDigits(num);
}
