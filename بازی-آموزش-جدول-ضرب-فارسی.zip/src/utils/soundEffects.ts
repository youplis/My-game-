// Synthesized Web Audio API sound effects and voice synthesis
// Independent of external audio files - 100% reliable across browsers and offline

class SoundController {
  private audioCtx: AudioContext | null = null;
  private isMuted: boolean = false;

  constructor() {
    // Check localStorage for saved sound preference
    const saved = localStorage.getItem('multiplication_app_muted');
    if (saved !== null) {
      this.isMuted = saved === 'true';
    }
  }

  private getAudioContext(): AudioContext | null {
    if (this.isMuted) return null;
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    localStorage.setItem('multiplication_app_muted', String(this.isMuted));
    if (this.isMuted && this.audioCtx && this.audioCtx.state === 'running') {
      this.audioCtx.suspend();
    }
    return this.isMuted;
  }

  /**
   * Pleasant chime for correct answer: C5 (523Hz) -> E5 (659Hz) -> G5 (784Hz) -> C6 (1046Hz)
   */
  public playCorrect(): void {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6

    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.08);

      gain.gain.setValueAtTime(0, now + i * 0.08);
      gain.gain.linearRampToValueAtTime(0.25, now + i * 0.08 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.08 + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + i * 0.08);
      osc.stop(now + i * 0.08 + 0.4);
    });
  }

  /**
   * Gentle, soft thud/buzz for wrong answer
   */
  public playWrong(): void {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    // Two low dissonant frequencies
    const notes = [220, 207.65]; // A3, G#3

    notes.forEach((freq) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.7, now + 0.35);

      // Low pass filter to make it mellow, not harsh for kids
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450, now);

      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.45);
    });
  }

  /**
   * Click sound for UI interactions
   */
  public playClick(): void {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(700, now);
    osc.frequency.exponentialRampToValueAtTime(350, now + 0.05);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.06);
  }

  /**
   * Realistic synthesized fireworks sound effect:
   * Ascending whistle rocket followed by an explosion burst and sizzling crackles!
   */
  public playFirework(): void {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    // 1. Whistle rocket launch
    const whistleOsc = ctx.createOscillator();
    const whistleGain = ctx.createGain();
    whistleOsc.type = 'sine';
    whistleOsc.frequency.setValueAtTime(400, now);
    whistleOsc.frequency.exponentialRampToValueAtTime(1400, now + 0.45);

    whistleGain.gain.setValueAtTime(0.01, now);
    whistleGain.gain.linearRampToValueAtTime(0.15, now + 0.3);
    whistleGain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

    whistleOsc.connect(whistleGain);
    whistleGain.connect(ctx.destination);

    whistleOsc.start(now);
    whistleOsc.stop(now + 0.46);

    // 2. Explosion boom (filtered white noise + low punch sine)
    const explosionDelay = 0.45;
    const explosionTime = now + explosionDelay;

    // Deep sub punch
    const subOsc = ctx.createOscillator();
    const subGain = ctx.createGain();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(160, explosionTime);
    subOsc.frequency.exponentialRampToValueAtTime(35, explosionTime + 0.6);

    subGain.gain.setValueAtTime(0.35, explosionTime);
    subGain.gain.exponentialRampToValueAtTime(0.001, explosionTime + 0.6);

    subOsc.connect(subGain);
    subGain.connect(ctx.destination);
    subOsc.start(explosionTime);
    subOsc.stop(explosionTime + 0.65);

    // Crackle noise burst
    try {
      const bufferSize = ctx.sampleRate * 0.8;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }

      const whiteNoise = ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(900, explosionTime);
      filter.frequency.exponentialRampToValueAtTime(300, explosionTime + 0.7);
      filter.Q.setValueAtTime(2.0, explosionTime);

      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.3, explosionTime);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, explosionTime + 0.75);

      whiteNoise.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(ctx.destination);

      whiteNoise.start(explosionTime);
      whiteNoise.stop(explosionTime + 0.8);
    } catch {
      // Audio buffer creation safe fallback
    }
  }

  /**
   * Triumphant level-up fanfare sequence + fireworks sound
   */
  public playLevelUp(): void {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Heroic fanfare notes: G4, C5, E5, G5, rest, G5, C6
    const fanfareNotes = [
      { freq: 392.0, time: 0, dur: 0.18 },
      { freq: 523.25, time: 0.2, dur: 0.18 },
      { freq: 659.25, time: 0.4, dur: 0.18 },
      { freq: 783.99, time: 0.6, dur: 0.35 },
      { freq: 783.99, time: 1.0, dur: 0.15 },
      { freq: 1046.5, time: 1.2, dur: 0.6 },
    ];

    fanfareNotes.forEach((n) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(n.freq, now + n.time);

      gain.gain.setValueAtTime(0, now + n.time);
      gain.gain.linearRampToValueAtTime(0.28, now + n.time + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, now + n.time + n.dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + n.time);
      osc.stop(now + n.time + n.dur + 0.05);
    });

    // Schedule 3 sequential firework bursts to celebrate!
    setTimeout(() => this.playFirework(), 500);
    setTimeout(() => this.playFirework(), 1100);
    setTimeout(() => this.playFirework(), 1700);
  }

  /**
   * Short, sweet, pleasant chime chord for stage victory (gentle on ears, no headache)
   */
  public playVictoryFanfare(): void {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    // Pleasant, soothing melodic chime: C5, E5, G5, C6 with warm sine tones
    const chimeNotes = [
      { freq: 523.25, time: 0, dur: 0.35, gain: 0.2 },
      { freq: 659.25, time: 0.1, dur: 0.4, gain: 0.22 },
      { freq: 783.99, time: 0.22, dur: 0.45, gain: 0.25 },
      { freq: 1046.5, time: 0.36, dur: 0.7, gain: 0.3 },
    ];

    chimeNotes.forEach((n) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(n.freq, now + n.time);

      gain.gain.setValueAtTime(0.001, now + n.time);
      gain.gain.linearRampToValueAtTime(n.gain, now + n.time + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + n.time + n.dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + n.time);
      osc.stop(now + n.time + n.dur + 0.05);
    });
  }


  /**
   * Speak Persian multiplication text out loud (e.g., "هفت ضرب در شش چند می‌شود؟")
   */
  public speakPersian(text: string): void {
    if (this.isMuted) return;
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'fa-IR';
    utterance.rate = 0.9;
    utterance.pitch = 1.05;

    // Pick Persian or Arabic voice if available
    const voices = window.speechSynthesis.getVoices();
    const faVoice = voices.find((v) => v.lang.startsWith('fa') || v.lang.includes('IR'));
    const arVoice = voices.find((v) => v.lang.startsWith('ar'));
    if (faVoice) {
      utterance.voice = faVoice;
    } else if (arVoice) {
      utterance.voice = arVoice;
    }

    window.speechSynthesis.speak(utterance);
  }
}

export const soundManager = new SoundController();
